=== TABARC IndexNow ===
Contributors: tabarc-code
Tags: indexnow, seo, indexing, bing, search engines
Requires at least: 6.4
Requires PHP: 7.4
Stable tag: 2.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Secure IndexNow notifications for public WordPress content, rebuilt and maintained by TABARC-Code, Inc.

== Description ==

TABARC IndexNow notifies IndexNow-compatible search engines when selected public content is added, updated or removed.

Version 2.0.1 packages the clean-room rebuild as a beginner-ready release. It uses native WordPress administration forms instead of a bundled React application and custom REST routes, with expanded installation, migration and troubleshooting documentation.

Features include:

* Automatic queued submissions for selected public post types.
* Immediate manual URL submission.
* Public API key verification file.
* Wildcard path exclusions, including paths relative to a subdirectory install.
* Optional noindex checks.
* Retry handling with exponential backoff and Retry-After support.
* Recent submission history and 48-hour counts.
* Media Library PNG icon selection for the admin menu.
* Conservative migration of old settings and recent history.

== Installation ==

1. Upload the plugin ZIP in Plugins > Add New > Upload Plugin.
2. Activate TABARC IndexNow.
3. Open IndexNow in the WordPress admin menu.
4. Review the generated key, post types and exclusions.
5. Test the public key-file link shown on the settings page.

== Frequently Asked Questions ==

= Does deactivation delete my data? =

No. Deactivation only clears scheduled tasks. Data is removed on uninstall only when you enable "Delete data on uninstall" first.

= Why is the API key not encrypted? =

IndexNow requires the same key to be publicly available in a text verification file. The former base64 encoding did not protect it. The new plugin stores the setting without autoloading it on every front-end request.

= Can I submit a URL on another domain? =

No. Manual and automatic URLs must match the WordPress site's host.

= Does IndexNow guarantee indexing? =

No. It tells participating search engines that a URL changed. Search engines still decide whether and when to crawl or index it.

== Changelog ==

= 2.0.1 =

* Added a complete beginner-first WordPress installation, migration and troubleshooting guide.
* Added GitHub-ready README, repository description, release notes and repository setup guidance.
* Added issue, pull-request, contribution and release-checklist files.
* Added a prepared release layout and checksum workflow.
* Updated author attribution to TABARC-Code, Inc.

= 2.0.0 =

* Clean-room rebuild by TABARC-Code, Inc.
* Replaced the React/custom REST admin application with native WordPress forms.
* Added nonce and capability checks for every administrative action.
* Added strict same-host URL validation and a fixed remote endpoint.
* Added batched background queue processing and bounded retry backoff.
* Added Retry-After handling for HTTP 429 responses.
* Added configurable public post types and wildcard path exclusions.
* Added optional rendered-page noindex detection.
* Added recent history, 48-hour counts and explicit retention limits.
* Added Media Library PNG admin icon selection.
* Added conservative migration from the older options and history tables.
* Stopped deleting data during ordinary deactivation.
