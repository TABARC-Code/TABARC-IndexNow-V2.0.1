# Contributing

Contributions should make the plugin safer, clearer or easier to maintain without turning a small notification tool into a framework audition.

## Before changing code

1. Read `docs/ARCHITECTURE.md`.
2. Read `SECURITY.md`.
3. Keep WordPress 6.4 and PHP 7.4 compatibility unless a documented release decision changes them.
4. Use UK English in administration copy and documentation.
5. Preserve native WordPress patterns for capabilities, nonces, sanitisation, escaping and HTTP requests.

## Code expectations

- Keep submitted URLs restricted to the current site.
- Do not make the remote endpoint administrator-configurable without a strong security case.
- Avoid new runtime dependencies unless they solve a real problem that native WordPress cannot reasonably solve.
- Add comments where the reason is not obvious. Do not narrate every brace.
- Keep comments human. A little context survives longer than a wall of ceremonial prose.
- Update `CHANGELOG.md` for user-visible changes.
- Update beginner documentation when settings or behaviour change.

## Basic checks

```bash
find . -name '*.php' -print0 | xargs -0 -n1 php -l
node --check assets/admin.js
```

Test activation, settings saving, key-file output, manual submission, queue processing, deactivation and uninstall on a disposable WordPress installation.

## Pull requests

Describe:

- The problem being solved.
- The practical behaviour before and after the change.
- Security implications.
- Migration implications.
- How the change was tested.

Large rewrites need a reason beyond preferring a different pattern. The previous plugin already demonstrated how quickly architecture can become the product instead of serving it.
