# TABARC IndexNow 2.0.1

Version 2.0.1 packages the clean-room rebuild as a complete beginner-ready release.

The plugin itself remains deliberately compact: native WordPress administration forms, a deduplicated background queue, strict same-site URL validation, bounded retries, optional noindex checks, recent history, migration support and a Media Library PNG admin icon.

This release adds the less glamorous material that determines whether software is actually usable after it leaves the programmer's machine:

- A fully rewritten GitHub `README.md`.
- `description.md` with repository, release and topic copy.
- A fast `START-HERE.md` route for WordPress administrators.
- A no-assumptions installation, migration and troubleshooting guide.
- A browser-first GitHub repository and release setup guide.
- Contribution guidance, issue templates and a pull-request template.
- Repository housekeeping through `.gitignore`, `.gitattributes` and `.editorconfig`.
- A prepared WordPress upload ZIP and SHA-256 checksum.
- Updated authorship as **TABARC-Code, Inc.**

## Download

For WordPress, download the attached:

```text
tabarc-indexnow-2.0.1.zip
```

Do not use GitHub's automatically generated **Source code** ZIP as the WordPress upload. It contains the repository rather than the clean install package. They look similar enough to cause confusion, because apparently archives required a minor identity crisis.

## Upgrade

Upload the new ZIP through **Plugins → Add New Plugin → Upload Plugin**. When upgrading from TABARC IndexNow 2.0.0, choose **Replace current with uploaded** if WordPress presents that option.

Settings and history are preserved during an ordinary upgrade or deactivation.
