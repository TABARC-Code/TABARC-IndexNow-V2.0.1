# Security policy

## Supported release

Security fixes are applied to the current 2.x release line.

## Reporting

Report a suspected vulnerability privately to the repository maintainer before publishing technical details. Include the affected version, reproduction steps, required role or capability, and the practical impact.

## Design notes

The plugin sends only the site's public host, selected public URLs and the IndexNow verification key to the fixed global IndexNow endpoint. It does not transmit post content, user records, passwords or Media Library files.

Administrative writes require both the `manage_options` capability and a valid WordPress nonce. Chosen admin icons are checked server-side for the `image/png` MIME type even though the Media Library picker is already filtered in the browser.

Loopback noindex checks use WordPress's safe HTTP client and are bounded by timeout, redirect and response-size limits.

The submission endpoint is not configurable through the user interface. That is less flexible, but it also prevents the feature becoming a convenient server-side request tool pointed at arbitrary hosts.
