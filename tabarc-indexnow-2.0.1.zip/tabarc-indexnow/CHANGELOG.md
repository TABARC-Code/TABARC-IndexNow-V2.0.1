# Changelog

## 2.0.1

- Reworked the repository documentation for ordinary WordPress administrators as well as developers.
- Added `description.md`, `START-HERE.md`, release notes and a complete beginner's guide.
- Added a browser-first GitHub setup and release guide.
- Added contribution guidance, issue templates, a pull-request template and a release checklist.
- Added `.gitignore`, `.gitattributes` and `.editorconfig` repository housekeeping.
- Prepared a separate installable WordPress archive and SHA-256 checksum layout.
- Updated author attribution to **TABARC-Code, Inc.**

## 2.0.0

- Rebuilt the plugin from a fresh TABARC-Code, Inc. architecture.
- Consolidated editable and deployable packages into one installable release.
- Removed the bundled React application, source maps and release-numbered REST namespace.
- Added native WordPress nonce and capability protection to all administration actions.
- Added strict local-host URL validation and a fixed IndexNow endpoint.
- Added queued batching, bounded retries, exponential backoff and `Retry-After` support.
- Added public post-type selection, wildcard exclusions and optional noindex checks.
- Added an explicit PNG Media Library field for the admin menu icon.
- Added migration of legacy API key, automatic-submission setting, excluded paths and recent history.
- Preserved data on deactivation and made uninstall deletion an explicit opt-in.
- Rewritten throughout in UK English with maintainer comments and future-facing notes.
