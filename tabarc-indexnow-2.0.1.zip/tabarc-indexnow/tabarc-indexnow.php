<?php
/**
 * Plugin Name:       TABARC IndexNow
 * Plugin URI:        https://github.com/TABARC-Code
 * Description:       Securely notifies IndexNow-compatible search engines when public WordPress content is added, updated or removed.
 * Version:           2.0.1
 * Author:            TABARC-Code, Inc.
 * Author URI:        https://github.com/TABARC-Code
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       tabarc-indexnow
 * Domain Path:       /languages
 * Requires at least: 6.4
 * Requires PHP:      7.4
 *
 * @package TABARC_IndexNow
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'TABARC_INDEXNOW_VERSION', '2.0.1' );
define( 'TABARC_INDEXNOW_FILE', __FILE__ );
define( 'TABARC_INDEXNOW_DIR', plugin_dir_path( __FILE__ ) );
define( 'TABARC_INDEXNOW_URL', plugin_dir_url( __FILE__ ) );

require_once TABARC_INDEXNOW_DIR . 'includes/class-options.php';
require_once TABARC_INDEXNOW_DIR . 'includes/class-repository.php';
require_once TABARC_INDEXNOW_DIR . 'includes/class-url-policy.php';
require_once TABARC_INDEXNOW_DIR . 'includes/class-submission-service.php';
require_once TABARC_INDEXNOW_DIR . 'includes/class-activator.php';
require_once TABARC_INDEXNOW_DIR . 'includes/class-deactivator.php';
require_once TABARC_INDEXNOW_DIR . 'includes/class-admin.php';
require_once TABARC_INDEXNOW_DIR . 'includes/class-plugin.php';

register_activation_hook( __FILE__, array( 'TABARC_IndexNow_Activator', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'TABARC_IndexNow_Deactivator', 'deactivate' ) );

TABARC_IndexNow_Plugin::instance()->boot();
