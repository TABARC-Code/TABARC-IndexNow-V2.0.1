# Clean-room rebuild audit

## Inputs examined

The two supplied archives represented one historical plugin in two forms:

1. editable React/TypeScript source plus WordPress PHP files;
2. the compiled WordPress package containing generated JavaScript, CSS and source maps.

The shared PHP implementation was effectively identical. Version 2.0.0 therefore treats them as source and build artefacts rather than two independent applications.

## Legacy issues not carried forward

- Deactivation deleted options and database tables.
- The admin REST namespace included the full plugin version, forcing client/server routing changes for every release.
- A large React bundle and multi-megabyte source map backed a relatively small settings dashboard.
- Static assets used random versions, defeating browser caching on each request.
- Several administrative operations returned HTTP 200 even for invalid requests.
- API keys were base64 encoded, which could be mistaken for protection despite being reversible encoding.
- Some URL validation did not firmly require the current site's host.
- The old Bing insights token bridge introduced extra state and a public callback without being necessary for IndexNow submission.
- Data cleanup occurred on deactivation rather than explicit uninstall.

## Rebuild decisions

- Native WordPress forms replace the front-end framework and custom REST API.
- All writes require `manage_options` plus a nonce.
- The IndexNow endpoint is fixed; submitted URLs must match the site host and WordPress public path.
- Automatic changes enter a deduplicated queue and are batched in the background.
- Retries are bounded and use exponential backoff, with `Retry-After` honoured when supplied.
- History retention is capped and configurable. Explicit uninstall also removes the plugin's saved permalink metadata.
- The verification key is served through an exact public text-file route.
- Existing legacy data is imported conservatively and left intact.
- A PNG attachment slot controls both the menu and page icon, with server-side MIME validation.

## Verification performed

The release is checked with PHP syntax linting, JavaScript syntax parsing, archive inspection and targeted static searches for common unsafe patterns. A real WordPress integration test remains advisable before production deployment because this environment does not include a complete WordPress site or its database.
