# GitHub setup guide for complete beginners

This guide explains how to turn the supplied repository package into a public or private GitHub repository, add the correct description and publish the installable WordPress ZIP as a release.

The browser method is first. A command-line method follows for anyone who already has Git installed or wants the more reliable long-term workflow.

## What is already prepared

The GitHub-ready package contains:

- The complete plugin source.
- `README.md` for the repository front page.
- `description.md` with ready-written repository copy and topics.
- `START-HERE.md` and the full beginner's installation guide.
- `CHANGELOG.md`, `SECURITY.md`, `CONTRIBUTING.md` and the GPL licence.
- Issue and pull-request templates under `.github/`.
- Repository housekeeping files such as `.gitignore`, `.gitattributes` and `.editorconfig`.
- A ready-to-upload WordPress plugin ZIP under `release/`.
- A SHA-256 checksum for the release ZIP.

Do not create replacement README, licence or ignore files when making the repository. They already exist here and are tailored to the project.

## Method A: set up the repository in a web browser

This repository is small enough for GitHub's browser uploader. GitHub currently permits up to 100 files in one browser upload, with a 25 MiB limit for each file. The package sits comfortably inside those limits.

### Step 1: extract the package

1. Download `tabarc-indexnow-2.0.1-github-ready.zip`.
2. Right-click it and choose **Extract All**, **Extract here** or the equivalent option on your system.
3. Open the extracted folder.
4. Confirm that `README.md`, `tabarc-indexnow.php`, `includes/` and `release/` are visible.

You will upload the **contents** of this folder, not another ZIP wrapped around it.

### Step 2: create an empty GitHub repository

1. Sign in to GitHub.
2. Use the **+** menu in the upper-right area and choose **New repository**.
3. Choose the owner account or organisation.
4. Enter this repository name:

   ```text
   tabarc-indexnow
   ```

5. Paste the short GitHub description from `description.md` into the description field.
6. Choose **Public** if everyone should be able to view and download it, or **Private** while you are still checking the release.
7. Do not add a README, `.gitignore` or licence from GitHub's creation form. The package already contains all three.
8. Select **Create repository**.

### Step 3: upload the prepared files

On the empty repository page:

1. Choose the link for **uploading an existing file**, or use **Add file → Upload files**.
2. Drag the extracted project files and folders into the upload area.
3. Check that the main files and folders are listed, including `.github`, `assets`, `docs`, `includes`, `release`, `README.md` and `tabarc-indexnow.php`.
4. In the commit message box, enter:

   ```text
   Initial TABARC IndexNow 2.0.1 release
   ```

5. Commit directly to the `main` branch for this first upload.
6. Select **Commit changes**.

If your operating system hides files beginning with a dot, `.github`, `.gitignore`, `.gitattributes` or `.editorconfig` may be missed. The plugin still works, but the repository loses some useful housekeeping. Use the command-line method below if those files will not upload cleanly.

### Step 4: add the repository description and topics

1. Return to the main repository page.
2. In the **About** area, select the settings or gear icon.
3. Paste the one-line repository description from `description.md`.
4. Add these topics:

   ```text
   wordpress
   wordpress-plugin
   indexnow
   seo
   search-engine-indexing
   php
   uk-english
   tabarc-code
   ```

5. Save the changes.

Topics are public metadata, even on a private repository, so do not use them for private project names or confidential client details.

### Step 5: check the repository front page

The contents of `README.md` should appear beneath the file list automatically.

Check that:

- The headings render correctly.
- The links to `START-HERE.md`, `SECURITY.md` and the `docs/` files open.
- `release/tabarc-indexnow-2.0.1.zip` is present.
- No passwords, private keys, `.env` files, client data or unrelated archives have been uploaded.

The IndexNow verification key used by the plugin is public by design, but there is no reason to commit a live site's settings or database export.

## Publish the WordPress plugin as a GitHub release

A GitHub release gives ordinary users a clear place to download the installable plugin. This matters because GitHub also generates automatic source-code ZIP and TAR archives for each tag. Those source archives are not the carefully prepared WordPress upload package.

### Step 1: open the release editor

1. Open the repository's main page.
2. Select **Releases**.
3. Select **Draft a new release**.

### Step 2: create the version tag

1. Open **Choose a tag**.
2. Type:

   ```text
   v2.0.1
   ```

3. Create the new tag from the `main` branch.
4. Use this release title:

   ```text
   TABARC IndexNow 2.0.1
   ```

### Step 3: add the release notes and files

1. Paste the contents of `RELEASE-NOTES.md` into the release description.
2. Attach these two files from the repository's `release/` folder:

   ```text
   tabarc-indexnow-2.0.1.zip
   tabarc-indexnow-2.0.1.sha256
   ```

3. Leave **pre-release** disabled because this is the stable package.
4. Mark it as the latest release where that option is shown.
5. Publish the release.

Users should download the attached `tabarc-indexnow-2.0.1.zip` asset. Make that explicit in the release notes so nobody installs GitHub's automatically generated source archive and then has a miserable afternoon.

## Method B: upload with Git on the command line

Use this method when Git is installed and you are comfortable opening Terminal, PowerShell or Git Bash.

### Step 1: create an empty repository on GitHub

Create `tabarc-indexnow` as described above. Do not initialise it with a README, licence or `.gitignore`.

### Step 2: initialise the extracted project folder

Open a terminal inside the extracted GitHub-ready folder and run:

```bash
git init -b main
git add .
git commit -m "Initial TABARC IndexNow 2.0.1 release"
```

### Step 3: connect it to GitHub

Copy the repository URL from GitHub's **Quick Setup** area, then run:

```bash
git remote add origin YOUR-REPOSITORY-URL
git remote -v
git push -u origin main
```

Replace `YOUR-REPOSITORY-URL` with the actual HTTPS or SSH URL.

GitHub requires command-line authentication. GitHub Desktop or GitHub CLI can handle that without manually storing a password.

## Optional method: GitHub CLI

With GitHub CLI installed and authenticated, run this from inside the extracted project folder:

```bash
git init -b main
git add .
git commit -m "Initial TABARC IndexNow 2.0.1 release"
gh repo create tabarc-indexnow --public --source=. --remote=origin --push
```

Change `--public` to `--private` when appropriate.

## Make later updates without replacing the repository

For each future release:

1. Edit the source and documentation in the existing repository folder.
2. Update the version in `tabarc-indexnow.php` and `readme.txt`.
3. Add a new section to `CHANGELOG.md`.
4. Rebuild the installable ZIP under `release/`.
5. Run the syntax and package checks.
6. Commit the changes.
7. Push to `main`.
8. Create a new tagged GitHub release and attach the new installable ZIP and checksum.

A typical command-line update looks like:

```bash
git add .
git commit -m "Prepare TABARC IndexNow 2.0.2"
git push
```

Use commit messages which describe the actual change. “Updated files” is technically true but not remotely useful six months later.

## Official GitHub references

- [Creating a new repository](https://docs.github.com/en/repositories/creating-and-managing-repositories/creating-a-new-repository)
- [Adding files to a repository](https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository)
- [Adding locally hosted code with Git](https://docs.github.com/en/migrations/importing-source-code/using-the-command-line-to-import-source-code/adding-locally-hosted-code-to-github)
- [Managing releases](https://docs.github.com/en/repositories/releasing-projects-on-github/managing-releases-in-a-repository)
- [Classifying a repository with topics](https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/classifying-your-repository-with-topics)
