# Complete beginner's guide

This guide assumes you know how to sign in to WordPress and very little else. It explains what to download, how to install the plugin, what every setting does, how to test it and what the common failure messages actually mean.

## 1. What IndexNow is

Search engines usually discover changes by crawling sites repeatedly. IndexNow lets a site send a small notification when a public URL changes.

The notification is not the page content. It contains the site's host, the changed URL or URLs, and the public verification key. A participating search engine may then decide to crawl the URL.

IndexNow does **not** guarantee indexing, ranking or traffic. It is a doorbell, not a court order.

## 2. Choose the right download

There may be two ZIP files around the project:

### The installable plugin ZIP

```text
tabarc-indexnow-2.0.1.zip
```

This is the file to upload in WordPress.

### The GitHub repository ZIP

A repository download contains the source, documentation, release files and Git housekeeping. It is useful for developers, but it is not the clean upload package.

If you are reading this inside the repository, the installable file is here:

```text
release/tabarc-indexnow-2.0.1.zip
```

## 3. Check the basic requirements

The plugin requires:

- WordPress 6.4 or later.
- PHP 7.4 or later.
- An administrator account.
- HTTPS is strongly recommended for the site as a whole.
- Outbound HTTPS requests from WordPress to the IndexNow service.

To check the WordPress and PHP versions:

1. Open **Tools → Site Health**.
2. Select **Info**.
3. Expand **WordPress** and **Server**.

If the versions are too old, update WordPress and ask the host about PHP before installing the plugin.

## 4. Back up first

For a new installation on a simple brochure site, the risk is small. Back up anyway.

For an upgrade, migration, shop, booking site or membership system, make a current file and database backup. Confirm that you know how the backup would be restored. A backup nobody can restore is mostly decorative.

## 5. Install through WordPress

1. Sign in to `/wp-admin/`.
2. Open **Plugins → Add New Plugin**.
3. Select **Upload Plugin**.
4. Select **Choose File**.
5. Choose `tabarc-indexnow-2.0.1.zip`.
6. Select **Install Now**.
7. Select **Activate Plugin**.

After activation, **IndexNow** appears in the main administration menu.

### If WordPress says the folder already exists

You probably have an earlier TABARC IndexNow release installed.

Use **Replace current with uploaded** when WordPress offers it. The plugin keeps its settings and history during an ordinary upgrade.

### If the upload is rejected as too large

This plugin ZIP is small. A size error usually means the wrong repository ZIP was selected or the host has an unusually restrictive upload limit.

Choose the release ZIP inside `release/`. If the correct file still fails, upload the extracted `tabarc-indexnow` folder to `/wp-content/plugins/` using the host's file manager or SFTP, then activate it from WordPress.

## 6. Migrate from an older IndexNow plugin

The safest sequence is:

1. Make a database backup.
2. Deactivate the old IndexNow plugin.
3. Do not delete it yet.
4. Install and activate TABARC IndexNow.
5. Open the new settings screen.
6. Confirm that the API key, automatic-submission setting and excluded paths look correct.
7. Test the key file.
8. Submit one public URL manually.
9. When everything works, remove the old plugin.

Do not run two plugins which both automatically notify IndexNow. Duplicate submissions waste requests and make diagnosis unnecessarily muddy.

The migration routine recognises these legacy settings:

```text
indexnow-admin_api_key
indexnow-auto_submission_enabled
indexnow-excluded_paths
```

It can also import up to 100 recent rows from recognised old success and failure tables. The rebuild deliberately leaves the original data untouched.

## 7. Understand the settings screen

### Automatic submission

Enable this to watch selected public content types.

When a relevant URL changes, the plugin adds it to a queue. Repeated saves collapse into one latest queue entry instead of generating a small avalanche because somebody corrected a comma three times.

Disabling the option pauses automatic processing. Existing queued URLs remain available.

### API key

The API key proves that the site controls the submitted host.

A valid key is generated during activation. Most users should not change it.

Use **Regenerate key** only when the current key is compromised, malformed or deliberately being replaced. Regenerating it changes the public verification filename as well.

### Public key file

The settings screen shows a link similar to:

```text
https://example.org/0123456789abcdef.txt
```

Open it. The page should:

- Return HTTP status 200.
- Show only the key in plain text.
- Not display the theme, menus or WordPress layout.

The key is intentionally public. It is not a login credential.

### Content types

Tick the public content types which should trigger automatic notifications.

Typical choices are:

- Posts
- Pages
- Public event entries
- Public products
- Other public custom post types

Do not select a type merely because it exists. Select it because its individual URLs should be discoverable by search engines.

### Excluded URL paths

Use this box to prevent automatic submissions for particular paths.

Enter one path per line:

```text
/member-area/*
/private-notes/*
/preview/?
/temporary-page
```

Wildcard rules:

- `*` matches any number of characters.
- `?` matches one character.

The match is made against the URL path. External hosts cannot be introduced through this setting.

Manual submissions intentionally ignore the automatic exclusion list. This lets an administrator test or deliberately send a local URL.

### Respect noindex directives

A `noindex` directive asks search engines not to index a page.

When this setting is enabled, the plugin checks recognised SEO metadata and may request the rendered page to inspect its robots directives before submitting additions or updates.

Keep it enabled for most sites. Disable it only when loopback requests are blocked and the site already guarantees that selected content is indexable.

Rendered-page checks use smaller worker batches because some hosts make local requests remarkably slow for machines allegedly sitting next to themselves.

### History records to retain

This controls the number of recent log rows stored in the database.

- Minimum: 100
- Maximum: 5,000

The history records the URL, event, status, HTTP result, a short note and the time. Full remote response bodies are not retained.

### Admin menu PNG icon

This controls the icon shown for the plugin in the WordPress administration area.

Recommended preparation:

- PNG format
- Square canvas
- About 64 × 64 pixels
- Transparent background where appropriate
- Simple silhouette that remains readable when small

To choose it:

1. Select **Choose PNG**.
2. Upload or select an image.
3. Confirm the selection.
4. Save settings.

The plugin performs a server-side MIME check. A WebP or JPEG renamed with a `.png` extension will not pass.

### Delete data on uninstall

Leave this disabled when you may reinstall the plugin or want to retain history.

Enable it only when removing the plugin permanently and deliberately. Uninstall will then delete the plugin's tables, options and saved permalink metadata.

Deactivation alone never deletes data.

## 8. Run the first tests

### Test A: the key file

Open the key-file link in a private browser window.

Expected result: one plain-text key and no themed page.

### Test B: manual submission

1. Copy the site's public home-page URL.
2. Paste it into **Manual submission**.
3. Select **Submit URL**.
4. Read the newest row in **Recent submission history**.

Typical successful results:

- `200`: accepted and processed.
- `202`: accepted for processing.

### Test C: automatic submission

1. Edit a public post or page selected in the settings.
2. Make a harmless change.
3. Update the content.
4. Return to **IndexNow**.
5. Check the queue count or recent history.
6. Use **Process queue now** if you want to test immediately.

In routine use, WordPress cron handles this in the background.

## 9. Understand WordPress cron

WordPress cron is request-driven by default. Scheduled jobs usually run when somebody visits the site after the scheduled time.

On a busy site, this is generally adequate. On a quiet site, queued work may wait until the next visit.

Some hosts disable WordPress cron and replace it with a real server cron job. That is fine when configured properly. If the queue never moves, ask the host whether `DISABLE_WP_CRON` is enabled and whether a replacement cron request is actually running.

The **Process queue now** button is useful after correcting a network, key or cron problem.

## 10. Common results and errors

### HTTP 200

The request succeeded.

### HTTP 202

The request was accepted for later processing. This is also a successful outcome.

### HTTP 400

The remote service considered the request malformed. Check the site URL and generated key, then retry.

### HTTP 403

The service did not accept the key or could not verify control of the site.

Open the public key file and confirm that it loads over the same host used in the submitted URL.

### HTTP 422

The key or URL relationship was not accepted. Check redirects, canonical host changes, `www` versus non-`www`, and subdirectory installations.

### HTTP 429

Too many requests were sent in a short period. The plugin respects `Retry-After` where supplied and otherwise uses bounded backoff.

Do not hammer **Process queue now** repeatedly. The server is already asking for less enthusiasm.

### HTTP 500 or 503

The remote service or an intermediary had a temporary problem. The queue will retry within its configured limits.

### Network or SSL error

WordPress could not complete the HTTPS request. Common causes include:

- Outbound requests blocked by the host.
- Broken server DNS.
- Invalid or incomplete SSL certificate chains.
- A firewall or security plugin blocking the request.
- cURL or OpenSSL problems on the server.

Check **Tools → Site Health** and ask the host to test outbound HTTPS from WordPress.

## 11. Troubleshooting the key file

### The key file returns 404

1. Open **Settings → Permalinks**.
2. Select **Save Changes** without changing anything.
3. Test the key-file URL again.

Saving permalinks refreshes WordPress rewrite rules.

Also clear any full-page cache, CDN cache or reverse-proxy cache.

### The key file shows the normal theme

Confirm that the exact generated filename is being opened. Then save permalinks and clear caches.

### The key file redirects to another host

Check **Settings → General** and confirm that the WordPress Address and Site Address use the intended public host and HTTPS form.

Canonical redirects between `www` and non-`www` are acceptable when the final host matches the URLs being submitted, but inconsistent settings can confuse verification.

## 12. Troubleshooting automatic submission

### Nothing appears in the queue

Check that:

- Automatic submission is enabled.
- The edited content type is ticked.
- The content is public.
- The URL is not excluded.
- The site is not set to discourage search engines.
- A `noindex` directive is not present when noindex checks are enabled.

### The queue count grows but never falls

Use **Process queue now** once and inspect the resulting history entry.

If nothing runs, investigate WordPress cron. If requests fail, investigate the HTTP result shown in history.

### Deleted content is still appearing in search

The plugin notifies IndexNow about the former URL, but removal from an index remains the search engine's decision. Confirm that the old URL returns the appropriate status or redirect.

## 13. Caching and security plugins

The public key file should not be replaced by a cached HTML page, blocked by a firewall rule or redirected to a challenge screen.

When using a CDN, cache plugin or web application firewall:

- Allow the generated root-level `.txt` path.
- Purge caches after regenerating the key.
- Do not inject HTML, cookie banners or bot challenges into the key response.
- Allow outbound HTTPS from the WordPress server to the IndexNow endpoint.

## 14. Safe removal

### Temporary deactivation

Use **Plugins → Deactivate**. Settings and history remain.

### Permanent removal while keeping data

Leave **Delete data on uninstall** disabled, then delete the plugin. This supports a later reinstall, although abandoned tables are still abandoned tables.

### Permanent removal including data

1. Open **IndexNow**.
2. Enable **Delete data on uninstall**.
3. Save settings.
4. Make a final backup if required.
5. Open **Plugins**.
6. Deactivate the plugin.
7. Delete it.

## 15. What information leaves the site

The plugin sends:

- The public host.
- Public URLs selected for notification.
- The public verification key.

It does not send post bodies, user accounts, passwords, private Media Library files or WordPress administration data.

## 16. Getting useful support

When reporting a problem, include:

- Plugin version.
- WordPress version.
- PHP version.
- Whether the site is single-site or multisite.
- The exact history status and HTTP code.
- Whether the public key file loads.
- Whether **Process queue now** works.
- Relevant Site Health errors.

Remove private URLs, credentials and personal data before posting logs publicly.

“Doesn't work” is emotionally valid but diagnostically underpowered.
