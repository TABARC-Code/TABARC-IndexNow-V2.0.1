# Build verification

The 2.0.1 package was checked with:

- PHP syntax linting across every shipped PHP file;
- JavaScript syntax parsing with Node;
- targeted smoke tests for key validation, local URL scope, subdirectory installs, exclusions, `noindex` parsing, fixed-endpoint payloads and HTTP response handling;
- repository smoke tests for inserts, duplicate replacement, format counts and prepared queue deletion;
- static searches for legacy class names, generated source maps, custom REST routes and common unsafe execution functions;
- documentation checks for required files, local Markdown links and current version references;
- inspection of the installable ZIP to confirm one top-level plugin folder and no nested release archive;
- SHA-256 generation for the final WordPress ZIP;
- a fresh extraction of the final ZIP followed by repeat linting and archive integrity checks.

These checks are useful, but they are not theatre props labelled “production assurance”. A live staging test remains sensible because hosting stacks differ in cron behaviour, loopback HTTP, rewrite rules, caching and outbound network policy.
