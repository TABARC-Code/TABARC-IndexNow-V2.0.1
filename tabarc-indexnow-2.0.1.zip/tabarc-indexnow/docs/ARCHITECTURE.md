# Architecture notes

## Shape of the plugin

`tabarc-indexnow.php` is intentionally dull. It defines constants, loads the small set of classes, registers activation/deactivation hooks and boots the coordinator. Dull bootstrap files are easier to audit and less likely to become a second application by accident.

The working parts are divided by responsibility:

- `class-options.php` owns defaults, validation and conservative migration.
- `class-repository.php` is the only class that writes submission and queue tables.
- `class-url-policy.php` decides whether a URL belongs to the site, matches an exclusion or declares `noindex`.
- `class-submission-service.php` is the protocol boundary. Its remote endpoint is fixed.
- `class-plugin.php` joins WordPress content hooks to the queue and worker.
- `class-admin.php` renders native forms and handles privileged actions.

No service container is used. For eight small classes it would mostly provide a decorative place to hide constructors.

## Submission flow

1. WordPress publishes, updates, unpublishes or deletes selected content.
2. The URL policy rejects non-public, foreign, out-of-scope or excluded URLs.
3. The repository stores one queue row per URL. A newer event replaces an older pending event for that same URL.
4. A single WordPress cron event wakes the worker near the earliest due time.
5. The worker rechecks policy, optionally inspects `noindex`, and submits a bounded batch.
6. Successful and terminal results are logged. Transient failures are delayed with bounded backoff.

The policy is checked twice on purpose. Settings can change while a URL waits, and queue data should never be treated as magically trustworthy merely because this plugin wrote it earlier.

## Stored data

- `tabarc_indexnow_settings`: non-autoloaded settings and public verification key.
- `tabarc_indexnow_schema_version`: migration marker.
- `tabarc_indexnow_worker_lock`: short-lived database lock for concurrent cron requests.
- `{$wpdb->prefix}tabarc_indexnow_queue`: pending work and retry state.
- `{$wpdb->prefix}tabarc_indexnow_log`: bounded submission history.
- `_tabarc_indexnow_last_url`: last known public permalink, needed before deletion or unpublishing.

Deactivation preserves all durable data. Explicit uninstall removes it only after the administrator opts in.

## Extension ideas

A future public hook immediately before batching would make specialist commerce integrations easier, but it should expose URLs rather than whole post objects. A WP-CLI command would also help larger sites inspect or drain the queue without making the admin screen pretend to be an operations console.

Multisite support deserves a deliberate design rather than a loop bolted onto activation. Network settings, per-site keys and network uninstall are different policy choices, not merely more `foreach`.
