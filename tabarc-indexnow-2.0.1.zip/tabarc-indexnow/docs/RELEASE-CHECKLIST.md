# Release checklist

Use this before publishing a new TABARC IndexNow version.

## Versioning

- [ ] Update the plugin header version in `tabarc-indexnow.php`.
- [ ] Update `TABARC_INDEXNOW_VERSION`.
- [ ] Update `Stable tag` in `readme.txt`.
- [ ] Update version references in installation and release documentation.
- [ ] Add the new release to `CHANGELOG.md`.

## Code and security

- [ ] Review every administrative write for capability and nonce checks.
- [ ] Validate and sanitise new inputs.
- [ ] Escape new output for the correct context.
- [ ] Confirm submitted URLs remain restricted to the current site.
- [ ] Review any new HTTP request for SSRF, timeout, redirect and response-size risk.
- [ ] Check activation, upgrade, deactivation and uninstall behaviour.

## Automated checks

```bash
find . -name '*.php' -print0 | xargs -0 -n1 php -l
node --check assets/admin.js
```

- [ ] All PHP files pass syntax linting.
- [ ] Admin JavaScript passes syntax checking.
- [ ] No generated source maps, dependency folders or environment files are included.

## Manual WordPress checks

- [ ] Fresh activation succeeds.
- [ ] Upgrade from the previous release succeeds.
- [ ] Settings save correctly.
- [ ] PNG selection and removal work.
- [ ] The public key file returns status 200 and plain text.
- [ ] Manual submission records a result.
- [ ] Automatic post updates enter the queue.
- [ ] Queue processing records success, skip or bounded failure correctly.
- [ ] Deactivation preserves data.
- [ ] Uninstall removes data only when explicitly enabled.

## Package checks

- [ ] The install ZIP contains one top-level `tabarc-indexnow/` folder.
- [ ] No `release/`, `.git/`, `.github/`, local tooling or previous ZIPs appear inside the install ZIP.
- [ ] The archive extracts without errors.
- [ ] The SHA-256 checksum matches the final ZIP.
- [ ] The GitHub-ready package contains the install ZIP under `release/`.

## GitHub release

- [ ] Commit and push the final source.
- [ ] Create the semantic version tag, such as `v2.0.1`.
- [ ] Paste the updated `RELEASE-NOTES.md`.
- [ ] Attach the installable ZIP.
- [ ] Attach the SHA-256 checksum.
- [ ] Mark the stable release as latest.
- [ ] Verify the release page clearly distinguishes the plugin ZIP from GitHub's source archives.
