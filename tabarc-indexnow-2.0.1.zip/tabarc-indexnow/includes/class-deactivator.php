<?php
/**
 * Deactivation work.
 *
 * @package TABARC_IndexNow
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TABARC_IndexNow_Deactivator {

	/**
	 * Deactivate without destroying the user's settings or history.
	 *
	 * The old package dropped its tables on deactivation. That turns routine
	 * troubleshooting into data loss, so the rebuild behaves like a civilised
	 * WordPress plugin and reserves deletion for uninstall.
	 *
	 * @return void
	 */
	public static function deactivate() {
		wp_clear_scheduled_hook( 'tabarc_indexnow_process_queue' );
		delete_option( 'tabarc_indexnow_worker_lock' );
	}
}
