<?php
/**
 * URL validation, exclusions and noindex checks.
 *
 * @package TABARC_IndexNow
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TABARC_IndexNow_URL_Policy {

	/**
	 * Normalise and validate a URL owned by this WordPress site.
	 *
	 * @param string $url Candidate URL.
	 * @return string|WP_Error
	 */
	public function normalise_local_url( $url ) {
		$url = esc_url_raw( trim( (string) $url ), array( 'http', 'https' ) );
		if ( '' === $url || ! wp_http_validate_url( $url ) ) {
			return new WP_Error( 'invalid_url', __( 'Enter a valid HTTP or HTTPS URL.', 'tabarc-indexnow' ) );
		}

		$parts = wp_parse_url( $url );
		$home  = wp_parse_url( home_url( '/' ) );
		if ( empty( $parts['host'] ) || empty( $home['host'] ) || strtolower( $parts['host'] ) !== strtolower( $home['host'] ) ) {
			return new WP_Error( 'foreign_host', __( 'The URL must belong to this site.', 'tabarc-indexnow' ) );
		}

		if ( isset( $parts['port'] ) || isset( $home['port'] ) ) {
			$url_port  = isset( $parts['port'] ) ? (int) $parts['port'] : 0;
			$home_port = isset( $home['port'] ) ? (int) $home['port'] : 0;
			if ( $url_port !== $home_port ) {
				return new WP_Error( 'foreign_port', __( 'The URL must use the same explicit network port as this site.', 'tabarc-indexnow' ) );
			}
		}
		if ( isset( $parts['user'] ) || isset( $parts['pass'] ) ) {
			return new WP_Error( 'credentials_in_url', __( 'URLs containing embedded credentials are not accepted.', 'tabarc-indexnow' ) );
		}

		// A WordPress install at example.test/blog should not claim URLs owned by
		// another application at example.test/shop. Host-only checks miss that.
		$home_path = isset( $home['path'] ) ? '/' . trim( (string) $home['path'], '/' ) : '';
		$url_path  = isset( $parts['path'] ) ? '/' . ltrim( (string) $parts['path'], '/' ) : '/';
		if ( '/' !== $home_path && '' !== $home_path && $url_path !== $home_path && 0 !== strpos( $url_path, trailingslashit( $home_path ) ) ) {
			return new WP_Error( 'outside_site_path', __( 'The URL must sit inside this WordPress site’s public path.', 'tabarc-indexnow' ) );
		}

		$url = preg_replace( '/#.*$/', '', $url );
		return is_string( $url ) ? $url : '';
	}

	/**
	 * Check whether an excluded path pattern matches a URL.
	 *
	 * @param string   $url      URL.
	 * @param string[] $patterns Path patterns.
	 * @return bool
	 */
	public function is_excluded( $url, array $patterns ) {
		$path = wp_parse_url( $url, PHP_URL_PATH );
		$path = is_string( $path ) && '' !== $path ? $path : '/';

		$paths     = array( $path );
		$home_path = wp_parse_url( home_url( '/' ), PHP_URL_PATH );
		$home_path = is_string( $home_path ) ? '/' . trim( $home_path, '/' ) : '';
		if ( '/' !== $home_path && '' !== $home_path && ( $path === $home_path || 0 === strpos( $path, trailingslashit( $home_path ) ) ) ) {
			$relative = substr( $path, strlen( $home_path ) );
			$paths[]  = '' === $relative ? '/' : $relative;
		}

		foreach ( $patterns as $pattern ) {
			$quoted = preg_quote( $pattern, '~' );
			$regex  = '~\A' . str_replace( array( '\*', '\?' ), array( '.*', '.' ), $quoted ) . '\z~i';
			foreach ( $paths as $candidate ) {
				if ( 1 === preg_match( $regex, $candidate ) ) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Decide whether a post should be considered public enough to notify.
	 *
	 * @param WP_Post $post Post object.
	 * @return bool
	 */
	public function is_public_post( WP_Post $post ) {
		if ( post_password_required( $post ) || ! empty( $post->post_password ) ) {
			return false;
		}
		if ( function_exists( 'is_post_publicly_viewable' ) ) {
			return is_post_publicly_viewable( $post );
		}
		$type = get_post_type_object( $post->post_type );
		return $type && $type->public && 'publish' === $post->post_status;
	}

	/**
	 * Check common metadata and the rendered response for noindex directives.
	 *
	 * The remote check happens in the background queue, not during the editor's
	 * save request. That avoids making the person pressing Publish wait for their
	 * own website to call itself, which is a fairly silly place to add latency.
	 *
	 * @param string      $url  URL.
	 * @param WP_Post|null $post Optional post.
	 * @return bool
	 */
	public function has_noindex( $url, $post = null ) {
		if ( '0' === (string) get_option( 'blog_public', '1' ) ) {
			return true;
		}

		if ( $post instanceof WP_Post && $this->has_known_noindex_meta( $post->ID ) ) {
			return true;
		}

		$response = wp_safe_remote_get(
			$url,
			array(
				'timeout'             => 3,
				'redirection'         => 3,
				'limit_response_size' => 262144,
				'user-agent'          => 'TABARC-IndexNow/' . TABARC_INDEXNOW_VERSION . '; ' . home_url( '/' ),
			)
		);
		if ( is_wp_error( $response ) ) {
			return false;
		}

		$header = wp_remote_retrieve_header( $response, 'x-robots-tag' );
		if ( is_string( $header ) && $this->directive_has_noindex( $header ) ) {
			return true;
		}

		$body = wp_remote_retrieve_body( $response );
		return '' !== $body && $this->html_has_noindex_meta( $body );
	}


	/**
	 * Look for exact noindex tokens rather than loose substrings.
	 *
	 * @param string $directive Robots directive text.
	 * @return bool
	 */
	private function directive_has_noindex( $directive ) {
		$tokens = preg_split( '/[\s,;:]+/', strtolower( html_entity_decode( $directive, ENT_QUOTES, 'UTF-8' ) ) );
		return is_array( $tokens ) && ( in_array( 'noindex', $tokens, true ) || in_array( 'none', $tokens, true ) );
	}

	/**
	 * Read robots meta tags without requiring the optional DOM extension.
	 *
	 * HTML in the wild is not always beautifully formed. Pulling out individual
	 * meta tags is deliberately modest, but more reliable than one heroic regex
	 * trying to understand every possible attribute order in a single gulp.
	 *
	 * @param string $html Rendered HTML.
	 * @return bool
	 */
	private function html_has_noindex_meta( $html ) {
		if ( ! preg_match_all( '~<meta\b[^>]*>~i', $html, $matches ) ) {
			return false;
		}

		foreach ( $matches[0] as $tag ) {
			if ( ! preg_match( '~\bname\s*=\s*(["\'])(robots|googlebot|bingbot)\1~i', $tag ) ) {
				continue;
			}
			if ( ! preg_match( '~\bcontent\s*=\s*(["\'])(.*?)\1~is', $tag, $content ) ) {
				continue;
			}
			if ( $this->directive_has_noindex( $content[2] ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Conservative compatibility checks for common SEO plugins.
	 *
	 * These are hints, not a claim that every plugin stores its settings this way
	 * forever. The rendered-page check remains the final, vendor-neutral test.
	 *
	 * @param int $post_id Post ID.
	 * @return bool
	 */
	private function has_known_noindex_meta( $post_id ) {
		$yoast = get_post_meta( $post_id, '_yoast_wpseo_meta-robots-noindex', true );
		if ( '1' === (string) $yoast ) {
			return true;
		}

		$rank_math = get_post_meta( $post_id, 'rank_math_robots', true );
		if ( is_array( $rank_math ) && in_array( 'noindex', $rank_math, true ) ) {
			return true;
		}

		$aioseo = get_post_meta( $post_id, '_aioseo_robots_default', true );
		$aioseo_noindex = get_post_meta( $post_id, '_aioseo_robots_noindex', true );
		if ( ! $aioseo && in_array( $aioseo_noindex, array( true, 1, '1' ), true ) ) {
			return true;
		}

		return false;
	}
}
