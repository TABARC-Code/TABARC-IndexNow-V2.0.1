<?php
/**
 * Main plugin coordinator.
 *
 * @package TABARC_IndexNow
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TABARC_IndexNow_Plugin {

	/** @var self|null */
	private static $instance;

	/** @var TABARC_IndexNow_Repository */
	private $repository;

	/** @var TABARC_IndexNow_URL_Policy */
	private $policy;

	/** @var TABARC_IndexNow_Submission_Service */
	private $service;

	/**
	 * Singleton accessor.
	 *
	 * @return self
	 */
	public static function instance() {
		if ( ! self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		$this->repository = new TABARC_IndexNow_Repository();
		$this->policy     = new TABARC_IndexNow_URL_Policy();
		$this->service    = new TABARC_IndexNow_Submission_Service();
	}

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function boot() {
		add_action( 'plugins_loaded', array( $this, 'load_textdomain' ) );
		add_action( 'init', array( $this, 'maybe_upgrade' ), 5 );
		add_action( 'init', array( $this, 'ensure_queue_schedule' ), 20 );
		add_action( 'template_redirect', array( $this, 'serve_key_file' ), 0 );
		add_filter( 'redirect_canonical', array( $this, 'protect_key_file_from_canonical_redirects' ), 10, 2 );

		add_action( 'transition_post_status', array( $this, 'on_status_transition' ), 20, 3 );
		add_action( 'before_delete_post', array( $this, 'on_before_delete_post' ), 20, 2 );
		add_action( 'post_updated', array( $this, 'on_post_updated' ), 20, 3 );
		add_action( 'tabarc_indexnow_process_queue', array( $this, 'process_queue' ) );

		if ( is_admin() ) {
			$admin = new TABARC_IndexNow_Admin( $this->repository, $this );
			$admin->register_hooks();
		}
	}

	/**
	 * Load translations.
	 *
	 * @return void
	 */
	public function load_textdomain() {
		load_plugin_textdomain( 'tabarc-indexnow', false, dirname( plugin_basename( TABARC_INDEXNOW_FILE ) ) . '/languages' );
	}

	/**
	 * Run schema upgrades when files are replaced without reactivation.
	 *
	 * @return void
	 */
	public function maybe_upgrade() {
		if ( TABARC_INDEXNOW_VERSION === get_option( TABARC_IndexNow_Options::SCHEMA_OPTION, '' ) ) {
			return;
		}
		$this->repository->install_schema();
		$this->repository->migrate_legacy_history();
		update_option( TABARC_IndexNow_Options::SCHEMA_OPTION, TABARC_INDEXNOW_VERSION, false );
	}

	/**
	 * Ensure queued work has one scheduled single event.
	 *
	 * @return void
	 */
	public function ensure_queue_schedule() {
		if ( ! TABARC_IndexNow_Options::get( 'enabled', true ) || $this->repository->queue_count() < 1 ) {
			return;
		}
		$next_due = $this->repository->next_available_at();
		$this->schedule_worker( max( time() + 15, $next_due ) );
	}

	/**
	 * Serve the public IndexNow key file from WordPress.
	 *
	 * @return void
	 */
	public function serve_key_file() {
		$key = (string) TABARC_IndexNow_Options::get( 'api_key', '' );
		if ( ! TABARC_IndexNow_Options::is_valid_key( $key ) ) {
			return;
		}

		$request_path = wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '', PHP_URL_PATH );
		$home_path    = wp_parse_url( home_url( '/' ), PHP_URL_PATH );
		$home_path    = '/' . trim( (string) $home_path, '/' );
		$home_path    = '/' === $home_path ? '' : $home_path;
		$expected     = $home_path . '/' . $key . '.txt';

		if ( $request_path !== $expected ) {
			return;
		}

		status_header( 200 );
		nocache_headers();
		header( 'Content-Type: text/plain; charset=utf-8' );
		header( 'X-Robots-Tag: noindex, nofollow', true );
		header( 'X-Content-Type-Options: nosniff', true );
		echo esc_html( $key );
		exit;
	}

	/**
	 * Stop WordPress guessing a prettier URL for the key file.
	 *
	 * @param string|false $redirect Redirect URL.
	 * @param string       $requested Requested URL.
	 * @return string|false
	 */
	public function protect_key_file_from_canonical_redirects( $redirect, $requested ) {
		$key = (string) TABARC_IndexNow_Options::get( 'api_key', '' );
		if ( $key && false !== strpos( (string) $requested, '/' . $key . '.txt' ) ) {
			return false;
		}
		return $redirect;
	}

	/**
	 * Handle publish/update/unpublish transitions.
	 *
	 * @param string  $new_status New status.
	 * @param string  $old_status Old status.
	 * @param WP_Post $post       Post.
	 * @return void
	 */
	public function on_status_transition( $new_status, $old_status, $post ) {
		if ( ! $post instanceof WP_Post || wp_is_post_revision( $post ) || wp_is_post_autosave( $post ) ) {
			return;
		}
		if ( ! $this->post_type_enabled( $post->post_type ) ) {
			return;
		}

		if ( 'publish' === $new_status ) {
			$url = get_permalink( $post );
			if ( $url ) {
				update_post_meta( $post->ID, '_tabarc_indexnow_last_url', esc_url_raw( $url ) );
				$this->enqueue_url( $url, 'publish' === $old_status ? 'updated' : 'added', $post );
			}
			return;
		}

		if ( 'publish' === $old_status ) {
			$url = get_post_meta( $post->ID, '_tabarc_indexnow_last_url', true );
			if ( ! $url ) {
				$url = get_permalink( $post );
			}
			$this->enqueue_url( $url, 'removed', null, true );
		}
	}

	/**
	 * Notify the old URL if a published permalink changed.
	 *
	 * @param int     $post_id     Post ID.
	 * @param WP_Post $post_after  New post.
	 * @param WP_Post $post_before Old post.
	 * @return void
	 */
	public function on_post_updated( $post_id, $post_after, $post_before ) {
		if ( 'publish' !== $post_before->post_status || 'publish' !== $post_after->post_status ) {
			return;
		}
		if ( ! $this->post_type_enabled( $post_after->post_type ) ) {
			return;
		}

		$previous = get_permalink( $post_before );
		$current  = get_permalink( $post_after );
		if ( $previous && $current && untrailingslashit( $previous ) !== untrailingslashit( $current ) ) {
			$this->enqueue_url( $previous, 'removed', null, true );
		}
		if ( $current ) {
			update_post_meta( $post_id, '_tabarc_indexnow_last_url', esc_url_raw( $current ) );
		}
	}

	/**
	 * Capture a URL before a post is permanently deleted.
	 *
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post    Post object.
	 * @return void
	 */
	public function on_before_delete_post( $post_id, $post ) {
		if ( ! $post instanceof WP_Post || ! $this->post_type_enabled( $post->post_type ) ) {
			return;
		}
		$url = get_post_meta( $post_id, '_tabarc_indexnow_last_url', true );
		if ( ! $url && 'publish' === $post->post_status ) {
			$url = get_permalink( $post );
		}
		if ( $url ) {
			$this->enqueue_url( $url, 'removed', null, true );
		}
	}

	/**
	 * Queue one URL after policy checks.
	 *
	 * @param string       $url          URL.
	 * @param string       $event_type   Event.
	 * @param WP_Post|null $post         Post.
	 * @param bool         $allow_missing Whether a removed URL may no longer resolve.
	 * @return bool
	 */
	public function enqueue_url( $url, $event_type, $post = null, $allow_missing = false ) {
		if ( ! TABARC_IndexNow_Options::get( 'enabled', true ) ) {
			return false;
		}
		$normal = $this->policy->normalise_local_url( $url );
		if ( is_wp_error( $normal ) ) {
			return false;
		}
		if ( $this->policy->is_excluded( $normal, (array) TABARC_IndexNow_Options::get( 'excluded_paths', array() ) ) ) {
			$this->repository->log( $normal, $event_type, 'skipped', 0, 'Matched an excluded path.' );
			return false;
		}
		if ( ! $allow_missing && $post instanceof WP_Post && ! $this->policy->is_public_post( $post ) ) {
			return false;
		}

		$post_id = $post instanceof WP_Post ? $post->ID : 0;
		$queued  = $this->repository->enqueue( $normal, $event_type, 10, $post_id );
		$this->schedule_worker( time() + 15 );
		return $queued;
	}

	/**
	 * Process due queue rows in one protocol batch.
	 *
	 * @return void
	 */
	public function process_queue() {
		if ( ! TABARC_IndexNow_Options::get( 'enabled', true ) ) {
			return;
		}

		$lock_time = absint( get_option( 'tabarc_indexnow_worker_lock', 0 ) );
		if ( $lock_time && $lock_time > time() - 5 * MINUTE_IN_SECONDS ) {
			return;
		}
		if ( $lock_time ) {
			delete_option( 'tabarc_indexnow_worker_lock' );
		}
		if ( ! add_option( 'tabarc_indexnow_worker_lock', time(), '', false ) ) {
			return;
		}

		try {
			$batch_size = TABARC_IndexNow_Options::get( 'respect_noindex', true ) ? 5 : 100;
			$items      = $this->repository->get_due( $batch_size );
			if ( empty( $items ) ) {
				return;
			}

			$submit_items = array();
			$delete_ids   = array();
			foreach ( $items as $item ) {
				$normal = $this->policy->normalise_local_url( $item->url );
				if ( is_wp_error( $normal ) ) {
					$this->repository->log( $item->url, $item->event_type, 'failed', 0, $normal->get_error_message() );
					$delete_ids[] = (int) $item->id;
					continue;
				}
				if ( $this->policy->is_excluded( $normal, (array) TABARC_IndexNow_Options::get( 'excluded_paths', array() ) ) ) {
					$this->repository->log( $normal, $item->event_type, 'skipped', 0, 'Matched an excluded path.' );
					$delete_ids[] = (int) $item->id;
					continue;
				}
				$related_post = ! empty( $item->post_id ) ? get_post( (int) $item->post_id ) : null;
				if ( 'removed' !== $item->event_type && TABARC_IndexNow_Options::get( 'respect_noindex', true ) && $this->policy->has_noindex( $normal, $related_post ) ) {
					$this->repository->log( $normal, $item->event_type, 'skipped', 0, 'A noindex directive was detected.' );
					$delete_ids[] = (int) $item->id;
					continue;
				}
				$submit_items[] = $item;
			}

			$this->repository->delete_queue_rows( $delete_ids );
			if ( empty( $submit_items ) ) {
				$this->repository->trim_log( (int) TABARC_IndexNow_Options::get( 'history_limit', 500 ) );
				return;
			}

			$result = $this->service->submit(
				wp_list_pluck( $submit_items, 'url' ),
				(string) TABARC_IndexNow_Options::get( 'api_key', '' )
			);

			if ( $result['success'] ) {
				$ids = array();
				foreach ( $submit_items as $item ) {
					$this->repository->log( $item->url, $item->event_type, 'success', $result['http_code'], $result['message'] );
					$ids[] = (int) $item->id;
				}
				$this->repository->delete_queue_rows( $ids );
			} else {
				foreach ( $submit_items as $item ) {
					$attempts = (int) $item->attempts + 1;
					if ( $result['retryable'] && $attempts < 5 ) {
						$delay = ! empty( $result['retry_after'] ) ? absint( $result['retry_after'] ) : min( 6 * HOUR_IN_SECONDS, 60 * ( 2 ** $attempts ) );
						$this->repository->reschedule( $item->id, $attempts, $delay, $result['message'] );
					} else {
						$this->repository->log( $item->url, $item->event_type, 'failed', $result['http_code'], $result['message'] );
						$this->repository->delete_queue_rows( array( (int) $item->id ) );
					}
				}
			}

			$this->repository->trim_log( (int) TABARC_IndexNow_Options::get( 'history_limit', 500 ) );
		} finally {
			delete_option( 'tabarc_indexnow_worker_lock' );
			if ( TABARC_IndexNow_Options::get( 'enabled', true ) && $this->repository->queue_count() > 0 ) {
				$next_due = $this->repository->next_available_at();
				$this->schedule_worker( max( time() + 15, $next_due ) );
			}
		}
	}

	/**
	 * Keep one queue event aimed at the earliest useful time.
	 *
	 * WordPress rejects near-duplicate single events. Replacing a later event is
	 * therefore necessary when a fresh publish arrives ahead of a long retry.
	 *
	 * @param int $timestamp Desired Unix timestamp.
	 * @return void
	 */
	private function schedule_worker( $timestamp ) {
		$timestamp = max( time() + 5, absint( $timestamp ) );
		$next      = wp_next_scheduled( 'tabarc_indexnow_process_queue' );
		if ( $next && $next <= $timestamp + 5 ) {
			return;
		}
		if ( $next ) {
			wp_unschedule_event( $next, 'tabarc_indexnow_process_queue' );
		}
		wp_schedule_single_event( $timestamp, 'tabarc_indexnow_process_queue' );
	}

	/**
	 * Submit one URL immediately from the admin screen.
	 *
	 * @param string $url URL.
	 * @return array<string,mixed>|WP_Error
	 */
	public function submit_manual( $url ) {
		$normal = $this->policy->normalise_local_url( $url );
		if ( is_wp_error( $normal ) ) {
			return $normal;
		}
		$result = $this->service->submit( array( $normal ), (string) TABARC_IndexNow_Options::get( 'api_key', '' ) );
		$this->repository->log( $normal, 'manual', $result['success'] ? 'success' : 'failed', $result['http_code'], $result['message'] );
		$this->repository->trim_log( (int) TABARC_IndexNow_Options::get( 'history_limit', 500 ) );
		return $result;
	}

	/**
	 * Is a post type enabled in settings?
	 *
	 * @param string $post_type Post type.
	 * @return bool
	 */
	private function post_type_enabled( $post_type ) {
		return in_array( $post_type, (array) TABARC_IndexNow_Options::get( 'post_types', array() ), true );
	}
}
