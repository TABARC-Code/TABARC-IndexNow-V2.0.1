<?php
/**
 * Activation and upgrade work.
 *
 * @package TABARC_IndexNow
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TABARC_IndexNow_Activator {

	/**
	 * Activate the plugin.
	 *
	 * @return void
	 */
	public static function activate() {
		$repository = new TABARC_IndexNow_Repository();
		$repository->install_schema();

		if ( false === get_option( TABARC_IndexNow_Options::OPTION_NAME, false ) ) {
			TABARC_IndexNow_Options::migrate_legacy_settings();
		}

		$repository->migrate_legacy_history();
		update_option( TABARC_IndexNow_Options::SCHEMA_OPTION, TABARC_INDEXNOW_VERSION, false );

	}
}
