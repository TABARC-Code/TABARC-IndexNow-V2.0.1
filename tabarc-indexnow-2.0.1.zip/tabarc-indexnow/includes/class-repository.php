<?php
/**
 * Database access for submission history and the retry queue.
 *
 * @package TABARC_IndexNow
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TABARC_IndexNow_Repository {

	/** @var wpdb */
	private $wpdb;

	/** @var string */
	private $log_table;

	/** @var string */
	private $queue_table;

	public function __construct() {
		global $wpdb;
		$this->wpdb        = $wpdb;
		$this->log_table   = $wpdb->prefix . 'tabarc_indexnow_log';
		$this->queue_table = $wpdb->prefix . 'tabarc_indexnow_queue';
	}

	/**
	 * Create or update the plugin tables.
	 *
	 * @return void
	 */
	public function install_schema() {
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$collate = $this->wpdb->get_charset_collate();

		$log_sql = "CREATE TABLE {$this->log_table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			url text NOT NULL,
			url_hash char(64) NOT NULL,
			event_type varchar(20) NOT NULL,
			status varchar(20) NOT NULL,
			http_code smallint(5) unsigned NOT NULL DEFAULT 0,
			message varchar(255) NOT NULL DEFAULT '',
			created_at bigint(20) unsigned NOT NULL,
			PRIMARY KEY  (id),
			KEY created_at (created_at),
			KEY status_created (status, created_at),
			KEY url_hash (url_hash)
		) $collate;";

		$queue_sql = "CREATE TABLE {$this->queue_table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			queue_hash char(64) NOT NULL,
			url text NOT NULL,
			event_type varchar(20) NOT NULL,
			post_id bigint(20) unsigned NOT NULL DEFAULT 0,
			attempts smallint(5) unsigned NOT NULL DEFAULT 0,
			available_at bigint(20) unsigned NOT NULL,
			created_at bigint(20) unsigned NOT NULL,
			last_error varchar(255) NOT NULL DEFAULT '',
			PRIMARY KEY  (id),
			UNIQUE KEY queue_hash (queue_hash),
			KEY available_at (available_at)
		) $collate;";

		dbDelta( $log_sql );
		dbDelta( $queue_sql );
	}

	/**
	 * Record one submission result.
	 *
	 * @param string $url        Submitted URL.
	 * @param string $event_type Event label.
	 * @param string $status     success, failed or skipped.
	 * @param int    $http_code  HTTP status code, where available.
	 * @param string $message    Human-readable note.
	 * @return void
	 */
	public function log( $url, $event_type, $status, $http_code = 0, $message = '' ) {
		$this->wpdb->insert(
			$this->log_table,
			array(
				'url'        => esc_url_raw( $url ),
				'url_hash'   => hash( 'sha256', (string) $url ),
				'event_type' => sanitize_key( $event_type ),
				'status'     => sanitize_key( $status ),
				'http_code'  => absint( $http_code ),
				'message'    => substr( sanitize_text_field( $message ), 0, 255 ),
				'created_at' => time(),
			),
			array( '%s', '%s', '%s', '%s', '%d', '%s', '%d' )
		);
	}

	/**
	 * Queue a URL, or bring an existing duplicate forward.
	 *
	 * @param string $url        URL.
	 * @param string $event_type Event label.
	 * @param int    $delay      Delay in seconds.
	 * @param int    $post_id    Related post ID, when available.
	 * @return bool
	 */
	public function enqueue( $url, $event_type, $delay = 0, $post_id = 0 ) {
		$url        = esc_url_raw( $url );
		$event_type = sanitize_key( $event_type );
		$hash       = hash( 'sha256', $url );
		$available  = time() + max( 0, absint( $delay ) );
		$post_id    = absint( $post_id );

		$existing_id = $this->wpdb->get_var(
			$this->wpdb->prepare(
				"SELECT id FROM {$this->queue_table} WHERE queue_hash = %s LIMIT 1",
				$hash
			)
		);

		if ( $existing_id ) {
			return false !== $this->wpdb->update(
				$this->queue_table,
				array(
					'event_type'   => $event_type,
					'post_id'      => $post_id,
					'attempts'     => 0,
					'available_at' => $available,
					'last_error'   => '',
				),
				array( 'id' => absint( $existing_id ) ),
				array( '%s', '%d', '%d', '%d', '%s' ),
				array( '%d' )
			);
		}

		return false !== $this->wpdb->insert(
			$this->queue_table,
			array(
				'queue_hash'  => $hash,
				'url'         => $url,
				'event_type'  => $event_type,
				'post_id'     => $post_id,
				'attempts'    => 0,
				'available_at' => $available,
				'created_at'  => time(),
				'last_error'  => '',
			),
			array( '%s', '%s', '%s', '%d', '%d', '%d', '%d', '%s' )
		);
	}

	/**
	 * Return due queue items.
	 *
	 * @param int $limit Maximum rows.
	 * @return array<int,object>
	 */
	public function get_due( $limit = 100 ) {
		$limit = min( 1000, max( 1, absint( $limit ) ) );
		$rows  = $this->wpdb->get_results(
			$this->wpdb->prepare(
				"SELECT * FROM {$this->queue_table} WHERE available_at <= %d ORDER BY available_at ASC, id ASC LIMIT %d",
				time(),
				$limit
			)
		);
		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Reschedule a queue row after a transient failure.
	 *
	 * @param int    $id         Row ID.
	 * @param int    $attempts   Attempt count.
	 * @param int    $delay      Delay seconds.
	 * @param string $last_error Error summary.
	 * @return void
	 */
	public function reschedule( $id, $attempts, $delay, $last_error ) {
		$this->wpdb->update(
			$this->queue_table,
			array(
				'attempts'    => absint( $attempts ),
				'available_at' => time() + max( 60, absint( $delay ) ),
				'last_error'  => substr( sanitize_text_field( $last_error ), 0, 255 ),
			),
			array( 'id' => absint( $id ) ),
			array( '%d', '%d', '%s' ),
			array( '%d' )
		);
	}

	/**
	 * Delete queue rows by ID.
	 *
	 * @param int[] $ids IDs.
	 * @return void
	 */
	public function delete_queue_rows( array $ids ) {
		$ids = array_values( array_filter( array_map( 'absint', $ids ) ) );
		if ( empty( $ids ) ) {
			return;
		}
		$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		$sql          = $this->wpdb->prepare( "DELETE FROM {$this->queue_table} WHERE id IN ($placeholders)", $ids );
		$this->wpdb->query( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Prepared immediately above.
	}

	/**
	 * Recent history.
	 *
	 * @param int $limit Number of rows.
	 * @return array<int,object>
	 */
	public function recent( $limit = 50 ) {
		$limit = min( 200, max( 1, absint( $limit ) ) );
		$rows  = $this->wpdb->get_results(
			$this->wpdb->prepare(
				"SELECT * FROM {$this->log_table} ORDER BY created_at DESC, id DESC LIMIT %d",
				$limit
			)
		);
		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Count statuses since a timestamp.
	 *
	 * @param int $since Unix timestamp.
	 * @return array<string,int>
	 */
	public function counts_since( $since ) {
		$rows = $this->wpdb->get_results(
			$this->wpdb->prepare(
				"SELECT status, COUNT(*) AS total FROM {$this->log_table} WHERE created_at >= %d GROUP BY status",
				absint( $since )
			),
			ARRAY_A
		);
		$counts = array( 'success' => 0, 'failed' => 0, 'skipped' => 0 );
		foreach ( (array) $rows as $row ) {
			$status = sanitize_key( $row['status'] );
			if ( isset( $counts[ $status ] ) ) {
				$counts[ $status ] = absint( $row['total'] );
			}
		}
		return $counts;
	}


	/**
	 * Earliest time at which a queued row is due.
	 *
	 * @return int
	 */
	public function next_available_at() {
		return absint( $this->wpdb->get_var( "SELECT MIN(available_at) FROM {$this->queue_table}" ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Static internal table name.
	}

	/**
	 * Number of queued rows.
	 *
	 * @return int
	 */
	public function queue_count() {
		return absint( $this->wpdb->get_var( "SELECT COUNT(*) FROM {$this->queue_table}" ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Static internal table name.
	}

	/**
	 * Remove all history rows.
	 *
	 * @return void
	 */
	public function clear_log() {
		$this->wpdb->query( "DELETE FROM {$this->log_table}" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Static internal table name.
	}

	/**
	 * Keep only the newest configured number of history records.
	 *
	 * @param int $limit Rows to retain.
	 * @return void
	 */
	public function trim_log( $limit ) {
		$limit = min( 5000, max( 100, absint( $limit ) ) );
		$sql   = $this->wpdb->prepare(
			"DELETE FROM {$this->log_table} WHERE id NOT IN (SELECT id FROM (SELECT id FROM {$this->log_table} ORDER BY id DESC LIMIT %d) AS newest)",
			$limit
		);
		$this->wpdb->query( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Prepared immediately above.
	}

	/**
	 * Import a small, useful slice of the legacy history tables.
	 *
	 * @return void
	 */
	public function migrate_legacy_history() {
		if ( get_option( 'tabarc_indexnow_history_migrated', false ) ) {
			return;
		}

		$legacy = array(
			'indexnow_passed_submissions' => 'success',
			'indexnow_failed_submissions' => 'failed',
		);

		foreach ( $legacy as $suffix => $status ) {
			$table = $this->wpdb->prefix . $suffix;
			$found = $this->wpdb->get_var( $this->wpdb->prepare( 'SHOW TABLES LIKE %s', $this->wpdb->esc_like( $table ) ) );
			if ( $found !== $table ) {
				continue;
			}
			$rows = $this->wpdb->get_results( "SELECT * FROM {$table} ORDER BY submission_date DESC LIMIT 100" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Verified internal table name.
			foreach ( (array) $rows as $row ) {
				$this->wpdb->insert(
					$this->log_table,
					array(
						'url'        => esc_url_raw( $row->url ),
						'url_hash'   => hash( 'sha256', (string) $row->url ),
						'event_type' => sanitize_key( $row->type ? $row->type : 'legacy' ),
						'status'     => $status,
						'http_code'  => 0,
						'message'    => substr( sanitize_text_field( $row->error ), 0, 255 ),
						'created_at' => absint( $row->submission_date ),
					),
					array( '%s', '%s', '%s', '%s', '%d', '%s', '%d' )
				);
			}
		}

		update_option( 'tabarc_indexnow_history_migrated', 1, false );
	}
}
