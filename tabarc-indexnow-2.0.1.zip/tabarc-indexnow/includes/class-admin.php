<?php
/**
 * Native WordPress administration screen.
 *
 * @package TABARC_IndexNow
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TABARC_IndexNow_Admin {

	/** @var TABARC_IndexNow_Repository */
	private $repository;
	/** @var TABARC_IndexNow_Plugin */
	private $plugin;
	/** @var string */
	private $page_hook = '';

	public function __construct( $repository, $plugin ) {
		$this->repository = $repository;
		$this->plugin     = $plugin;
	}

	/** Register admin hooks. */
	public function register_hooks() {
		add_action( 'admin_menu', array( $this, 'add_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( TABARC_INDEXNOW_FILE ), array( $this, 'action_links' ) );
		add_action( 'admin_post_tabarc_indexnow_save_settings', array( $this, 'save_settings' ) );
		add_action( 'admin_post_tabarc_indexnow_manual_submit', array( $this, 'manual_submit' ) );
		add_action( 'admin_post_tabarc_indexnow_clear_log', array( $this, 'clear_log' ) );
		add_action( 'admin_post_tabarc_indexnow_process_queue', array( $this, 'process_queue_now' ) );
	}

	/** Add the top-level menu. */
	public function add_menu() {
		$this->page_hook = add_menu_page(
			__( 'TABARC IndexNow', 'tabarc-indexnow' ),
			__( 'IndexNow', 'tabarc-indexnow' ),
			'manage_options',
			'tabarc-indexnow',
			array( $this, 'render_page' ),
			$this->menu_icon(),
			80
		);
	}

	/** Enqueue only on this plugin screen. */
	public function enqueue_assets( $hook ) {
		if ( $hook !== $this->page_hook ) {
			return;
		}
		wp_enqueue_media();
		wp_enqueue_style( 'tabarc-indexnow-admin', TABARC_INDEXNOW_URL . 'assets/admin.css', array(), TABARC_INDEXNOW_VERSION );
		wp_enqueue_script( 'tabarc-indexnow-admin', TABARC_INDEXNOW_URL . 'assets/admin.js', array( 'jquery' ), TABARC_INDEXNOW_VERSION, true );
		wp_localize_script(
			'tabarc-indexnow-admin',
			'tabarcIndexNowAdmin',
			array(
				'chooseTitle' => __( 'Choose a PNG admin icon', 'tabarc-indexnow' ),
				'chooseButton'=> __( 'Use this PNG', 'tabarc-indexnow' ),
				'pngOnly'     => __( 'Please choose a PNG image.', 'tabarc-indexnow' ),
			)
		);
	}

	/** Plugin list Settings link. */
	public function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=tabarc-indexnow' ) ) . '">' . esc_html__( 'Settings', 'tabarc-indexnow' ) . '</a>' );
		return $links;
	}

	/** Render the complete admin page. */
	public function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to manage this plugin.', 'tabarc-indexnow' ), esc_html__( 'Access denied', 'tabarc-indexnow' ), array( 'response' => 403 ) );
		}

		$settings = TABARC_IndexNow_Options::get_all();
		$counts   = $this->repository->counts_since( time() - 48 * HOUR_IN_SECONDS );
		$recent   = $this->repository->recent( 50 );
		$queued   = $this->repository->queue_count();
		$key_url  = home_url( '/' . rawurlencode( $settings['api_key'] ) . '.txt' );
		$post_types = get_post_types( array( 'public' => true ), 'objects' );
		unset( $post_types['attachment'] );
		?>
		<div class="wrap tabarc-indexnow-wrap">
			<?php $this->render_notice(); ?>
			<header class="tabarc-indexnow-header">
				<?php echo $this->icon_markup( $settings['admin_icon_id'], 'tabarc-indexnow-heading-icon' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Method returns escaped markup. ?>
				<div>
					<h1><?php esc_html_e( 'TABARC IndexNow', 'tabarc-indexnow' ); ?></h1>
					<p><?php echo esc_html( sprintf( __( 'Version %s, rebuilt and maintained by TABARC-Code, Inc.', 'tabarc-indexnow' ), TABARC_INDEXNOW_VERSION ) ); ?></p>
				</div>
			</header>

			<div class="tabarc-indexnow-cards" aria-label="<?php esc_attr_e( 'Submission summary', 'tabarc-indexnow' ); ?>">
				<?php $this->summary_card( __( 'Automatic submission', 'tabarc-indexnow' ), $settings['enabled'] ? __( 'Enabled', 'tabarc-indexnow' ) : __( 'Disabled', 'tabarc-indexnow' ), $settings['enabled'] ? 'good' : 'muted' ); ?>
				<?php $this->summary_card( __( 'Successful', 'tabarc-indexnow' ), (string) $counts['success'], 'good', __( 'Last 48 hours', 'tabarc-indexnow' ) ); ?>
				<?php $this->summary_card( __( 'Failed', 'tabarc-indexnow' ), (string) $counts['failed'], $counts['failed'] ? 'bad' : 'muted', __( 'Last 48 hours', 'tabarc-indexnow' ) ); ?>
				<?php $this->summary_card( __( 'Queued', 'tabarc-indexnow' ), (string) $queued, $queued ? 'warn' : 'muted' ); ?>
			</div>

			<div class="tabarc-indexnow-grid">
				<main>
					<section class="tabarc-indexnow-panel">
						<h2><?php esc_html_e( 'Settings', 'tabarc-indexnow' ); ?></h2>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
							<input type="hidden" name="action" value="tabarc_indexnow_save_settings">
							<?php wp_nonce_field( 'tabarc_indexnow_save_settings' ); ?>

							<div class="tabarc-field">
								<label class="tabarc-switch-row">
									<input type="checkbox" name="enabled" value="1" <?php checked( $settings['enabled'] ); ?>>
									<span><strong><?php esc_html_e( 'Enable automatic submissions', 'tabarc-indexnow' ); ?></strong><small><?php esc_html_e( 'Queue notifications when selected public content is added, changed or removed.', 'tabarc-indexnow' ); ?></small></span>
								</label>
							</div>

							<div class="tabarc-field">
								<label for="tabarc-api-key"><strong><?php esc_html_e( 'IndexNow API key', 'tabarc-indexnow' ); ?></strong></label>
								<div class="tabarc-inline-control">
									<input id="tabarc-api-key" class="regular-text code" type="text" name="api_key" value="<?php echo esc_attr( $settings['api_key'] ); ?>" minlength="8" maxlength="128" pattern="[A-Za-z0-9-]{8,128}" autocomplete="off" spellcheck="false">
									<button class="button" type="submit" name="regenerate_key" value="1"><?php esc_html_e( 'Generate a new key', 'tabarc-indexnow' ); ?></button>
								</div>
								<p class="description"><?php esc_html_e( 'Changing the key also changes the public verification filename. Search engines will verify the new file on the next submission.', 'tabarc-indexnow' ); ?></p>
								<p><a href="<?php echo esc_url( $key_url ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Open the public key file', 'tabarc-indexnow' ); ?></a></p>
							</div>

							<fieldset class="tabarc-field">
								<legend><strong><?php esc_html_e( 'Content types', 'tabarc-indexnow' ); ?></strong></legend>
								<div class="tabarc-checkbox-grid">
									<?php foreach ( $post_types as $type ) : ?>
										<label><input type="checkbox" name="post_types[]" value="<?php echo esc_attr( $type->name ); ?>" <?php checked( in_array( $type->name, (array) $settings['post_types'], true ) ); ?>> <?php echo esc_html( $type->labels->name ); ?></label>
									<?php endforeach; ?>
								</div>
							</fieldset>

							<div class="tabarc-field">
								<label for="tabarc-excluded-paths"><strong><?php esc_html_e( 'Excluded URL paths', 'tabarc-indexnow' ); ?></strong></label>
								<textarea id="tabarc-excluded-paths" name="excluded_paths" rows="6" class="large-text code" placeholder="/private/*&#10;/preview/?"><?php echo esc_textarea( implode( "\n", (array) $settings['excluded_paths'] ) ); ?></textarea>
								<p class="description"><?php esc_html_e( 'One path per line. Use * for any number of characters and ? for one character. Matching is against the path only, not the domain.', 'tabarc-indexnow' ); ?></p>
							</div>

							<div class="tabarc-field">
								<label class="tabarc-switch-row">
									<input type="checkbox" name="respect_noindex" value="1" <?php checked( $settings['respect_noindex'] ); ?>>
									<span><strong><?php esc_html_e( 'Respect noindex directives', 'tabarc-indexnow' ); ?></strong><small><?php esc_html_e( 'Check common SEO metadata and the rendered page before submitting additions or updates.', 'tabarc-indexnow' ); ?></small></span>
								</label>
							</div>

							<div class="tabarc-field tabarc-two-columns">
								<div>
									<label for="tabarc-history-limit"><strong><?php esc_html_e( 'History records to retain', 'tabarc-indexnow' ); ?></strong></label>
									<input id="tabarc-history-limit" type="number" name="history_limit" value="<?php echo esc_attr( $settings['history_limit'] ); ?>" min="100" max="5000" step="100">
								</div>
								<div>
									<label class="tabarc-switch-row">
										<input type="checkbox" name="delete_data_on_uninstall" value="1" <?php checked( $settings['delete_data_on_uninstall'] ); ?>>
										<span><strong><?php esc_html_e( 'Delete data on uninstall', 'tabarc-indexnow' ); ?></strong><small><?php esc_html_e( 'Deactivation never deletes settings or history.', 'tabarc-indexnow' ); ?></small></span>
									</label>
								</div>
							</div>

							<div class="tabarc-field">
								<label><strong><?php esc_html_e( 'Admin menu PNG icon', 'tabarc-indexnow' ); ?></strong></label>
								<div class="tabarc-icon-picker">
									<div id="tabarc-icon-preview"><?php echo $this->icon_markup( $settings['admin_icon_id'], 'tabarc-icon-preview-image' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
									<input type="hidden" id="tabarc-admin-icon-id" name="admin_icon_id" value="<?php echo esc_attr( $settings['admin_icon_id'] ); ?>">
									<button type="button" class="button" id="tabarc-choose-icon"><?php esc_html_e( 'Choose PNG', 'tabarc-indexnow' ); ?></button>
									<button type="button" class="button button-link-delete" id="tabarc-remove-icon"><?php esc_html_e( 'Remove', 'tabarc-indexnow' ); ?></button>
								</div>
								<p class="description"><?php esc_html_e( 'A square PNG around 64 × 64 pixels works best. WordPress will scale it for the menu.', 'tabarc-indexnow' ); ?></p>
							</div>

							<?php submit_button( __( 'Save settings', 'tabarc-indexnow' ) ); ?>
						</form>
					</section>

					<section class="tabarc-indexnow-panel">
						<div class="tabarc-panel-heading">
							<div><h2><?php esc_html_e( 'Recent submission history', 'tabarc-indexnow' ); ?></h2><p><?php esc_html_e( 'The newest 50 records are shown.', 'tabarc-indexnow' ); ?></p></div>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('<?php echo esc_js( __( 'Clear all recorded submission history?', 'tabarc-indexnow' ) ); ?>');">
								<input type="hidden" name="action" value="tabarc_indexnow_clear_log">
								<?php wp_nonce_field( 'tabarc_indexnow_clear_log' ); ?>
								<button class="button" type="submit"><?php esc_html_e( 'Clear history', 'tabarc-indexnow' ); ?></button>
							</form>
						</div>
						<div class="tabarc-table-scroll">
							<table class="widefat striped">
								<thead><tr><th><?php esc_html_e( 'URL', 'tabarc-indexnow' ); ?></th><th><?php esc_html_e( 'Event', 'tabarc-indexnow' ); ?></th><th><?php esc_html_e( 'Status', 'tabarc-indexnow' ); ?></th><th><?php esc_html_e( 'HTTP', 'tabarc-indexnow' ); ?></th><th><?php esc_html_e( 'Note', 'tabarc-indexnow' ); ?></th><th><?php esc_html_e( 'Time', 'tabarc-indexnow' ); ?></th></tr></thead>
								<tbody>
								<?php if ( empty( $recent ) ) : ?>
									<tr><td colspan="6"><?php esc_html_e( 'No submissions have been recorded yet.', 'tabarc-indexnow' ); ?></td></tr>
								<?php else : foreach ( $recent as $row ) : ?>
									<tr>
										<td class="tabarc-url-cell"><a href="<?php echo esc_url( $row->url ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $row->url ); ?></a></td>
										<td><?php echo esc_html( ucfirst( $row->event_type ) ); ?></td>
										<td><span class="tabarc-status tabarc-status-<?php echo esc_attr( $row->status ); ?>"><?php echo esc_html( ucfirst( $row->status ) ); ?></span></td>
										<td><?php echo $row->http_code ? esc_html( $row->http_code ) : '&ndash;'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static entity. ?></td>
										<td><?php echo esc_html( $row->message ); ?></td>
										<td><?php echo esc_html( wp_date( 'j M Y, H:i', (int) $row->created_at ) ); ?></td>
									</tr>
								<?php endforeach; endif; ?>
								</tbody>
							</table>
						</div>
					</section>
				</main>

				<aside>
					<section class="tabarc-indexnow-panel">
						<h2><?php esc_html_e( 'Manual submission', 'tabarc-indexnow' ); ?></h2>
						<p><?php esc_html_e( 'Submit one URL from this site immediately. Manual submissions deliberately ignore the automatic exclusion list.', 'tabarc-indexnow' ); ?></p>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
							<input type="hidden" name="action" value="tabarc_indexnow_manual_submit">
							<?php wp_nonce_field( 'tabarc_indexnow_manual_submit' ); ?>
							<label class="screen-reader-text" for="tabarc-manual-url"><?php esc_html_e( 'URL to submit', 'tabarc-indexnow' ); ?></label>
							<input id="tabarc-manual-url" class="large-text" type="url" name="url" value="<?php echo esc_attr( home_url( '/' ) ); ?>" required>
							<?php submit_button( __( 'Submit URL', 'tabarc-indexnow' ), 'primary', 'submit', false ); ?>
						</form>
					</section>

					<section class="tabarc-indexnow-panel">
						<h2><?php esc_html_e( 'Queue tools', 'tabarc-indexnow' ); ?></h2>
						<p><?php echo esc_html( sprintf( _n( '%s URL is waiting.', '%s URLs are waiting.', $queued, 'tabarc-indexnow' ), number_format_i18n( $queued ) ) ); ?></p>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
							<input type="hidden" name="action" value="tabarc_indexnow_process_queue">
							<?php wp_nonce_field( 'tabarc_indexnow_process_queue' ); ?>
							<button class="button" type="submit" <?php disabled( 0 === $queued ); ?>><?php esc_html_e( 'Process queue now', 'tabarc-indexnow' ); ?></button>
						</form>
						<p class="description"><?php esc_html_e( 'WordPress cron normally handles this. The button is mainly useful after fixing a network or key problem.', 'tabarc-indexnow' ); ?></p>
					</section>

					<section class="tabarc-indexnow-panel tabarc-maintainer-note">
						<h2><?php esc_html_e( 'Implementation note', 'tabarc-indexnow' ); ?></h2>
						<p><?php esc_html_e( 'This rebuild uses WordPress forms, capabilities and nonces rather than a separate React application and a collection of custom REST routes. Fewer moving parts means fewer dependencies to age badly in a cupboard.', 'tabarc-indexnow' ); ?></p>
						<p><a href="<?php echo esc_url( 'https://www.indexnow.org/documentation' ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Read the IndexNow protocol documentation', 'tabarc-indexnow' ); ?></a></p>
					</section>
				</aside>
			</div>
		</div>
		<?php
	}

	/** Save settings. */
	public function save_settings() {
		$this->authorise( 'tabarc_indexnow_save_settings' );
		$key = isset( $_POST['regenerate_key'] ) ? TABARC_IndexNow_Options::generate_key() : sanitize_text_field( wp_unslash( isset( $_POST['api_key'] ) ? $_POST['api_key'] : '' ) );
		if ( ! TABARC_IndexNow_Options::is_valid_key( $key ) ) {
			$this->redirect( 'invalid-key' );
		}

		$public_types = get_post_types( array( 'public' => true ), 'names' );
		unset( $public_types['attachment'] );
		$chosen_types = isset( $_POST['post_types'] ) ? (array) wp_unslash( $_POST['post_types'] ) : array();
		$chosen_types = array_values( array_intersect( array_map( 'sanitize_key', $chosen_types ), $public_types ) );

		$icon_id = isset( $_POST['admin_icon_id'] ) ? absint( $_POST['admin_icon_id'] ) : 0;
		if ( $icon_id && ! $this->is_png_attachment( $icon_id ) ) {
			$icon_id = 0;
		}

		$settings = array(
			'enabled'                  => isset( $_POST['enabled'] ),
			'api_key'                  => $key,
			'excluded_paths'           => TABARC_IndexNow_Options::sanitise_path_list( isset( $_POST['excluded_paths'] ) ? wp_unslash( $_POST['excluded_paths'] ) : '' ),
			'post_types'               => $chosen_types,
			'respect_noindex'          => isset( $_POST['respect_noindex'] ),
			'history_limit'            => min( 5000, max( 100, absint( isset( $_POST['history_limit'] ) ? $_POST['history_limit'] : 500 ) ) ),
			'admin_icon_id'            => $icon_id,
			'delete_data_on_uninstall' => isset( $_POST['delete_data_on_uninstall'] ),
		);
		TABARC_IndexNow_Options::save( $settings );
		if ( $settings['enabled'] ) {
			$this->plugin->ensure_queue_schedule();
		} else {
			wp_clear_scheduled_hook( 'tabarc_indexnow_process_queue' );
		}
		$this->repository->trim_log( $settings['history_limit'] );
		$this->redirect( 'settings-saved' );
	}

	/** Submit a manual URL. */
	public function manual_submit() {
		$this->authorise( 'tabarc_indexnow_manual_submit' );
		$url    = isset( $_POST['url'] ) ? wp_unslash( $_POST['url'] ) : '';
		$result = $this->plugin->submit_manual( $url );
		if ( is_wp_error( $result ) ) {
			$this->redirect( 'manual-error', $result->get_error_message() );
		}
		$this->redirect( $result['success'] ? 'manual-success' : 'manual-error', $result['message'] );
	}

	/** Clear history. */
	public function clear_log() {
		$this->authorise( 'tabarc_indexnow_clear_log' );
		$this->repository->clear_log();
		$this->redirect( 'history-cleared' );
	}

	/** Process queue from admin. */
	public function process_queue_now() {
		$this->authorise( 'tabarc_indexnow_process_queue' );
		$this->plugin->process_queue();
		$this->redirect( 'queue-processed' );
	}

	/** Common authorisation. */
	private function authorise( $nonce_action ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to perform this action.', 'tabarc-indexnow' ), esc_html__( 'Access denied', 'tabarc-indexnow' ), array( 'response' => 403 ) );
		}
		check_admin_referer( $nonce_action );
	}

	/** Redirect back with a compact notice code. */
	private function redirect( $notice, $detail = '' ) {
		$url = add_query_arg(
			array_filter(
				array(
					'page'   => 'tabarc-indexnow',
					'tabarc_notice' => sanitize_key( $notice ),
					'tabarc_detail' => $detail ? substr( sanitize_text_field( $detail ), 0, 180 ) : '',
				)
			),
			admin_url( 'admin.php' )
		);
		wp_safe_redirect( $url );
		exit;
	}

	/** Render redirect notice. */
	private function render_notice() {
		$code = isset( $_GET['tabarc_notice'] ) ? sanitize_key( wp_unslash( $_GET['tabarc_notice'] ) ) : '';
		$detail = isset( $_GET['tabarc_detail'] ) ? sanitize_text_field( wp_unslash( $_GET['tabarc_detail'] ) ) : '';
		$messages = array(
			'settings-saved' => array( 'success', __( 'Settings saved.', 'tabarc-indexnow' ) ),
			'invalid-key'    => array( 'error', __( 'The API key must be 8 to 128 letters, numbers or hyphens.', 'tabarc-indexnow' ) ),
			'manual-success' => array( 'success', __( 'The URL was accepted by IndexNow.', 'tabarc-indexnow' ) ),
			'manual-error'   => array( 'error', __( 'The URL could not be submitted.', 'tabarc-indexnow' ) ),
			'history-cleared'=> array( 'success', __( 'Submission history cleared.', 'tabarc-indexnow' ) ),
			'queue-processed'=> array( 'success', __( 'The due queue was processed.', 'tabarc-indexnow' ) ),
		);
		if ( ! isset( $messages[ $code ] ) ) {
			return;
		}
		list( $class, $message ) = $messages[ $code ];
		?>
		<div class="notice notice-<?php echo esc_attr( $class ); ?> is-dismissible"><p><strong><?php echo esc_html( $message ); ?></strong><?php if ( $detail ) : ?> <?php echo esc_html( $detail ); ?><?php endif; ?></p></div>
		<?php
	}

	/** Return menu icon URL or dashicon. */
	private function menu_icon() {
		$id = absint( TABARC_IndexNow_Options::get( 'admin_icon_id', 0 ) );
		if ( $this->is_png_attachment( $id ) ) {
			$url = wp_get_attachment_image_url( $id, 'thumbnail' );
			if ( $url ) {
				return $url;
			}
		}
		return 'dashicons-share-alt2';
	}

	/** Escaped icon markup. */
	private function icon_markup( $id, $class ) {
		$id = absint( $id );
		if ( $this->is_png_attachment( $id ) ) {
			$url = wp_get_attachment_image_url( $id, 'thumbnail' );
			if ( $url ) {
				return '<img class="' . esc_attr( $class ) . '" src="' . esc_url( $url ) . '" alt="">';
			}
		}
		return '<span class="dashicons dashicons-share-alt2 ' . esc_attr( $class ) . '" aria-hidden="true"></span>';
	}


	/**
	 * Confirm the chosen icon is a real PNG attachment.
	 *
	 * @param int $id Attachment ID.
	 * @return bool
	 */
	private function is_png_attachment( $id ) {
		$id = absint( $id );
		return $id && wp_attachment_is_image( $id ) && 'image/png' === get_post_mime_type( $id );
	}

	/** Summary card helper. */
	private function summary_card( $label, $value, $tone, $small = '' ) {
		?>
		<div class="tabarc-card tabarc-card-<?php echo esc_attr( $tone ); ?>"><span><?php echo esc_html( $label ); ?></span><strong><?php echo esc_html( $value ); ?></strong><?php if ( $small ) : ?><small><?php echo esc_html( $small ); ?></small><?php endif; ?></div>
		<?php
	}
}
