<?php
/**
 * IndexNow protocol client.
 *
 * @package TABARC_IndexNow
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TABARC_IndexNow_Submission_Service {

	const ENDPOINT = 'https://api.indexnow.org/indexnow';
	const MAX_URLS = 10000;

	/**
	 * Submit URLs to the fixed global IndexNow endpoint.
	 *
	 * @param string[] $urls URLs.
	 * @param string   $key  API key.
	 * @return array<string,mixed>
	 */
	public function submit( array $urls, $key ) {
		if ( ! TABARC_IndexNow_Options::is_valid_key( $key ) ) {
			return $this->result( false, false, 0, 'The IndexNow key is invalid.' );
		}

		$home = wp_parse_url( home_url( '/' ) );
		$host = isset( $home['host'] ) ? strtolower( $home['host'] ) : '';
		if ( '' === $host ) {
			return $this->result( false, false, 0, 'WordPress could not determine the site host.' );
		}

		$clean_urls = array();
		foreach ( $urls as $url ) {
			$url   = esc_url_raw( $url, array( 'http', 'https' ) );
			$parts = $url ? wp_parse_url( $url ) : false;
			if ( ! is_array( $parts ) || empty( $parts['host'] ) || strtolower( $parts['host'] ) !== $host ) {
				continue;
			}
			$clean_urls[] = $url;
		}
		$urls = array_slice( array_values( array_unique( $clean_urls ) ), 0, self::MAX_URLS );

		if ( empty( $urls ) ) {
			return $this->result( false, false, 0, 'No valid local URLs were supplied.' );
		}

		$payload = array(
			'host'        => $host,
			'key'         => $key,
			'keyLocation' => home_url( '/' . rawurlencode( $key ) . '.txt' ),
			'urlList'     => $urls,
		);

		$response = wp_remote_post(
			self::ENDPOINT,
			array(
				'timeout'     => 12,
				'redirection' => 0,
				'headers'     => array(
					'Accept'       => 'application/json',
					'Content-Type' => 'application/json; charset=utf-8',
					'User-Agent'   => 'TABARC-IndexNow/' . TABARC_INDEXNOW_VERSION . '; ' . home_url( '/' ),
				),
				'body'        => wp_json_encode( $payload, JSON_UNESCAPED_SLASHES ),
				'data_format' => 'body',
			)
		);

		if ( is_wp_error( $response ) ) {
			return $this->result( false, true, 0, $response->get_error_message() );
		}

		$code        = absint( wp_remote_retrieve_response_code( $response ) );
		$retry_after = $this->parse_retry_after( wp_remote_retrieve_header( $response, 'retry-after' ) );

		switch ( $code ) {
			case 200:
				return $this->result( true, false, $code, 'Accepted by IndexNow.' );
			case 202:
				return $this->result( true, false, $code, 'Accepted; key verification is pending.' );
			case 400:
				return $this->result( false, false, $code, 'IndexNow rejected the request format.' );
			case 403:
				return $this->result( false, false, $code, 'IndexNow could not verify the API key.' );
			case 422:
				return $this->result( false, false, $code, 'One or more URLs did not match the submitted host or key.' );
			case 429:
				$result                = $this->result( false, true, $code, 'IndexNow rate-limited the request.' );
				$result['retry_after'] = $retry_after;
				return $result;
			default:
				return $this->result( false, $code >= 500 || 0 === $code, $code, 'Unexpected response from IndexNow.' );
		}
	}

	/**
	 * Create a consistent result array.
	 *
	 * @param bool   $success   Success flag.
	 * @param bool   $retryable Retry flag.
	 * @param int    $code      HTTP code.
	 * @param string $message   Summary.
	 * @return array<string,mixed>
	 */
	private function result( $success, $retryable, $code, $message ) {
		return array(
			'success'     => (bool) $success,
			'retryable'   => (bool) $retryable,
			'http_code'   => absint( $code ),
			'message'     => sanitize_text_field( $message ),
			'retry_after' => 0,
		);
	}

	/**
	 * Parse Retry-After seconds or HTTP date.
	 *
	 * @param mixed $value Header value.
	 * @return int
	 */
	private function parse_retry_after( $value ) {
		if ( is_numeric( $value ) ) {
			return min( DAY_IN_SECONDS, max( 60, absint( $value ) ) );
		}
		if ( is_string( $value ) && '' !== $value ) {
			$time = strtotime( $value );
			if ( false !== $time ) {
				return min( DAY_IN_SECONDS, max( 60, $time - time() ) );
			}
		}
		return 0;
	}
}
