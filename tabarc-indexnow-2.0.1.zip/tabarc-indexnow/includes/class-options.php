<?php
/**
 * Plugin options and migration helpers.
 *
 * @package TABARC_IndexNow
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class TABARC_IndexNow_Options {

	const OPTION_NAME = 'tabarc_indexnow_settings';
	const SCHEMA_OPTION = 'tabarc_indexnow_schema_version';

	/**
	 * Default settings.
	 *
	 * The defaults cover posts, pages and products without enabling every public
	 * object a third-party plugin happens to register. Some plugins expose
	 * surprisingly odd internal content types as public.
	 *
	 * @return array<string,mixed>
	 */
	public static function defaults() {
		return array(
			'enabled'                  => true,
			'api_key'                  => '',
			'excluded_paths'           => array(),
			'post_types'               => self::default_post_types(),
			'respect_noindex'          => true,
			'history_limit'            => 500,
			'admin_icon_id'            => 0,
			'delete_data_on_uninstall' => false,
		);
	}

	/**
	 * Return all settings with defaults filled in.
	 *
	 * @return array<string,mixed>
	 */
	public static function get_all() {
		$stored = get_option( self::OPTION_NAME, array() );
		if ( ! is_array( $stored ) ) {
			$stored = array();
		}

		$settings = wp_parse_args( $stored, self::defaults() );
		if ( ! self::is_valid_key( $settings['api_key'] ) ) {
			$settings['api_key'] = self::generate_key();
			self::save( $settings );
		}

		return $settings;
	}

	/**
	 * Return one setting.
	 *
	 * @param string $key     Setting key.
	 * @param mixed  $default Fallback value.
	 * @return mixed
	 */
	public static function get( $key, $default = null ) {
		$settings = self::get_all();
		return array_key_exists( $key, $settings ) ? $settings[ $key ] : $default;
	}

	/**
	 * Save a complete settings array without autoloading it on every front-end request.
	 *
	 * @param array<string,mixed> $settings Settings to save.
	 * @return bool
	 */
	public static function save( array $settings ) {
		if ( false === get_option( self::OPTION_NAME, false ) ) {
			return add_option( self::OPTION_NAME, $settings, '', false );
		}

		return update_option( self::OPTION_NAME, $settings, false );
	}

	/**
	 * Create a protocol-compatible key.
	 *
	 * @return string
	 */
	public static function generate_key() {
		return str_replace( '-', '', wp_generate_uuid4() );
	}

	/**
	 * Validate an IndexNow key.
	 *
	 * @param string $key Candidate key.
	 * @return bool
	 */
	public static function is_valid_key( $key ) {
		return is_string( $key ) && 1 === preg_match( '/\A[A-Za-z0-9-]{8,128}\z/', $key );
	}

	/**
	 * Get a safe set of post types to enable on a typical site.
	 *
	 * @return string[]
	 */
	public static function default_post_types() {
		return array( 'post', 'page', 'product' );
	}

	/**
	 * Import settings from the old IndexNow package once.
	 *
	 * Base64 was used by the old plugin, but it was only encoding, not encryption.
	 * The rebuilt plugin stores the key plainly because it must publish that same
	 * value in a public verification file. Pretending otherwise buys no security.
	 *
	 * @return array<string,mixed>
	 */
	public static function migrate_legacy_settings() {
		$settings            = self::defaults();
		$settings['api_key'] = self::generate_key();

		$legacy_key = get_option( 'indexnow-admin_api_key', '' );
		if ( is_string( $legacy_key ) && '' !== $legacy_key ) {
			$decoded = base64_decode( $legacy_key, true );
			if ( is_string( $decoded ) && self::is_valid_key( $decoded ) ) {
				$settings['api_key'] = $decoded;
			} elseif ( self::is_valid_key( $legacy_key ) ) {
				$settings['api_key'] = $legacy_key;
			}
		}

		$legacy_enabled = get_option( 'indexnow-auto_submission_enabled', null );
		if ( null !== $legacy_enabled ) {
			$settings['enabled'] = '1' === (string) $legacy_enabled;
		}

		$legacy_paths = get_option( 'indexnow-excluded_paths', '' );
		if ( ( is_string( $legacy_paths ) && '' !== trim( $legacy_paths ) ) || is_array( $legacy_paths ) ) {
			$settings['excluded_paths'] = self::sanitise_path_list( $legacy_paths );
		}

		self::save( $settings );
		return $settings;
	}

	/**
	 * Sanitise path patterns.
	 *
	 * @param mixed $paths Raw paths.
	 * @return string[]
	 */
	public static function sanitise_path_list( $paths ) {
		if ( is_string( $paths ) ) {
			$paths = preg_split( '/\R/', $paths );
		}
		if ( ! is_array( $paths ) ) {
			return array();
		}

		$clean = array();
		foreach ( array_slice( $paths, 0, 50 ) as $path ) {
			$path = trim( sanitize_text_field( (string) $path ) );
			if ( '' === $path ) {
				continue;
			}
			if ( '/' !== substr( $path, 0, 1 ) ) {
				$path = '/' . $path;
			}
			$clean[] = substr( $path, 0, 200 );
		}

		return array_values( array_unique( $clean ) );
	}
}
