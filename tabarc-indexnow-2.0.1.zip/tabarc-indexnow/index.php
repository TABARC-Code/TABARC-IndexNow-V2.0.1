<?php
// Silence is golden. It also stops directory listings being more interesting than they deserve.
