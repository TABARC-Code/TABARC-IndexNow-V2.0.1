(function ($) {
	'use strict';

	var frame;
	var $id = $('#tabarc-admin-icon-id');
	var $preview = $('#tabarc-icon-preview');

	$('#tabarc-choose-icon').on('click', function (event) {
		event.preventDefault();

		if (frame) {
			frame.open();
			return;
		}

		frame = wp.media({
			title: tabarcIndexNowAdmin.chooseTitle,
			button: { text: tabarcIndexNowAdmin.chooseButton },
			library: { type: 'image/png' },
			multiple: false
		});

		frame.on('select', function () {
			var attachment = frame.state().get('selection').first().toJSON();
			if (attachment.mime !== 'image/png') {
				window.alert(tabarcIndexNowAdmin.pngOnly);
				return;
			}
			$id.val(attachment.id);
			$preview.html($('<img>', {
				'class': 'tabarc-icon-preview-image',
				src: attachment.sizes && attachment.sizes.thumbnail ? attachment.sizes.thumbnail.url : attachment.url,
				alt: ''
			}));
		});

		frame.open();
	});

	$('#tabarc-remove-icon').on('click', function (event) {
		event.preventDefault();
		$id.val('0');
		$preview.html('<span class="dashicons dashicons-share-alt2 tabarc-icon-preview-image" aria-hidden="true"></span>');
	});
}(jQuery));
