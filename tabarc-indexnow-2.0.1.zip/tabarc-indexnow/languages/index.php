<?php
// Silence is preferable to a directory listing.
