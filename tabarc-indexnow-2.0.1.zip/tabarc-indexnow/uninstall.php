<?php
/**
 * Uninstall cleanup.
 *
 * @package TABARC_IndexNow
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$settings = get_option( 'tabarc_indexnow_settings', array() );
if ( empty( $settings['delete_data_on_uninstall'] ) ) {
	return;
}

global $wpdb;
$log_table   = $wpdb->prefix . 'tabarc_indexnow_log';
$queue_table = $wpdb->prefix . 'tabarc_indexnow_queue';

$wpdb->query( "DROP TABLE IF EXISTS {$log_table}" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Internal table name.
$wpdb->query( "DROP TABLE IF EXISTS {$queue_table}" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Internal table name.
$wpdb->delete( $wpdb->postmeta, array( 'meta_key' => '_tabarc_indexnow_last_url' ), array( '%s' ) );

delete_option( 'tabarc_indexnow_settings' );
delete_option( 'tabarc_indexnow_schema_version' );
delete_option( 'tabarc_indexnow_history_migrated' );
delete_option( 'tabarc_indexnow_worker_lock' );
wp_clear_scheduled_hook( 'tabarc_indexnow_process_queue' );
